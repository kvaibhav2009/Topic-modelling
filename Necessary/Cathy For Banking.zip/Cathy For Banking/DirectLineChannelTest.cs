﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI
{
    public class DirectLineChannelTest
    {
        private string url = "https://directline.botframework.com/api/conversations/";
        private string key = "hbjOo9-6hyY.cwA.QKc.hlz_T6yKA-977WI0PR_rnROlhQ7U637DjvDlNf9T3Dw";

        public void main()
        {
            
        }
    }
}