﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI
{
    public class ConversationFeedbackSentiment
    {

        string FeedbackId { get; set; }
        string ConversationId { get; set; }
        string RequestId { get; set; }
        string ResponseId { get; set; }
        string FeedbackSentiment { get; set; }
        DateTime CreatedDate { get; set; }
        string FeedbackGivenBy { get; set; }

        public ConversationFeedbackSentiment(string feedbackId, string conversationId, string requestId, string responseId, string feedbackSentiment, DateTime createdDate, string feedbackGivenBy)
        {
            this.FeedbackId = feedbackId;
            this.ConversationId = conversationId;
            this.RequestId = requestId;
            this.ResponseId = responseId;
            this.FeedbackSentiment = feedbackSentiment;
            this.CreatedDate = createdDate;
            this.FeedbackGivenBy = feedbackSentiment;
        }

    }
}