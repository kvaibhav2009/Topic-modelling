﻿using CathyRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Tracing;

namespace CathyRestAPI.Controllers
{
    public class CathyMessageExchangeController : ApiController
    {
        private static TraceSource _source = new TraceSource("Logs");
        public string GetCathyMessageExchange()
        {
            return "HelloWorld ";
        }
        public CathyResponse PostCathyMessageExchange(CathyRequest request)
        {
            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t message exchange start");
            CathyRequestOrchestrator objRequestOrchestrator = new CathyRequestOrchestrator();
            CathyResponse response = objRequestOrchestrator.processMessage(request);
            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t message exchange end");
            return response;
        }
    }
}
