﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class RequestOrchestratorDummy
    {
        public void askQuery()
        { }

        //
        //UserProfileManager manager = new UserProfileManager()
        //UserProfile userprofile =  manager.getUserProfile (CathyRequest)
        // if(userprofile != null)
        // {
        // isSenderAgent(U)
        //{
        //   create this as a conversationresponse; 
        //}
        //

        //      CathyConversation conversation = getConversation(UserProfile)
        //        if (conversation == null)
        //        {
        //          conversation = createConversation(UserProfile, CathyRequest) --- updateConversationID in userprofile
        //          conversationRequest = createConversationRequest(USerProfile, CathyRequest)
        //         }
        //         else
        //         {    if(conversationstatus != close) then
        //              conversationRequest = createConversationRequest(UserProfile, CathyRequest)
        //              else
        //              createConversation()
        //              createConversationRequest()
        //         }
        //  }else
        //  {
        //       userProfile =  createUserProfile(CathyRequest)
        //       conversation = createConversation(UserProfile, CathyRequest)    
        //       conversationRequest = createConversationRequest(USerProfile, CathyRequest)
        //   }
        //   if(request.getSentiment == NEGATIVE)
        //  {
        //      CreateConversationResponse with action as closeAgentNegative  ---update conversation status in conversation
        // }else
        // {
        //     CALL LUIS
        //     CreateConversationResponse with action as closeAgentNegative  ---update conversation status in conversation
        //  }
    }
}