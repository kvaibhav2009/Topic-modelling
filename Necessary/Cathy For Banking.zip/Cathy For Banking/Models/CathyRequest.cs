﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class CathyRequest
    {
        public string Channel { get; set; }
        public string SenderId { get; set; }
        public string PostId { get; set; }
        public string ParentPostId { get; set; }
        public string SentimentValue { get; set; }
        public bool IsPrivateMessage { get; set; }
        public string RequestMessage { get; set; }
        public string SenderName { get; set; }
        public long requestMessageTimestamp { get; set; }

    }
}