﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class CathyResponse
    {
        public string Channel { get; set; }
        public string SenderId { get; set; }
        public string PostId { get; set; }
        public string Action { get; set; }
        public string AgentId { get; set; }
        public bool IsPrivateMessage { get; set; }
        public string ResponseMessage { get; set; }

}
}