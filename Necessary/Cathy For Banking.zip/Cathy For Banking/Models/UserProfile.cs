﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class UserProfile
    {
            string userProfileId;
            string twitterId;
            string fbWallId;
            string fbDirectId;
            string customerId;
            string senderName;
            public string LastCathyConversationId { get;  set;}
            string lastUserAgentConversationId;
        bool isDuplicateProfile;
            System.DateTime createdDate;
            System.DateTime updatedDate;

            public string UserProfileId
            {
                get
                {
                    return userProfileId;
                }

                set
                {
                    userProfileId = value;
                }
            }

            public string TwitterId
            {
                get
                {
                    return twitterId;
                }

                set
                {
                    twitterId = value;
                }
            }

            public string FbWallId
            {
                get
                {
                    return fbWallId;
                }

                set
                {
                    fbWallId = value;
                }
            }

            public string FbDirectId
            {
                get
                {
                    return fbDirectId;
                }

                set
                {
                    fbDirectId = value;
                }
            }

            public string CustomerId
            {
                get
                {
                    return customerId;
                }

                set
                {
                    customerId = value;
                }
            }

        public string SenderName
        {
            get
            {
                return senderName;
            }

            set
            {
                senderName = value;
            }
        }


       

            public DateTime CreatedDate
            {
                get
                {
                    return createdDate;
                }

                set
                {
                    createdDate = value;
                }
            }

            public DateTime UpdatedDate
            {
                get
                {
                    return updatedDate;
                }

                set
                {
                    updatedDate = value;
                }
            }

            public bool IsDuplicateProfile
            {
                get
                {
                    return isDuplicateProfile;
                }

                set
                {
                    isDuplicateProfile = value;
                }
            }

        public string LastUserAgentConversationId
        {
            get
            {
                return lastUserAgentConversationId;
            }

            set
            {
                lastUserAgentConversationId = value;
            }
        }

      

        public UserProfile(string senderId, string channel, bool isPrivateMessage)
            {

                if (channel.Equals(CathyConstants.twitterChannel))
                    TwitterId = senderId;
                else if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == true)
                    FbDirectId = senderId;
                else
                    FbWallId = senderId;

            }

            public UserProfile(string userProfileId, string senderName, string twitterId, string fbWallId, string fbPrivateId, string customerId, string lastCathyConversationId, string lastUserAgentConversationId, bool isDuplicateProfile, DateTime createdDate, DateTime updatedDate)
            {
                this.userProfileId = userProfileId;
                this.senderName = senderName;
                this.twitterId = twitterId;
                this.fbWallId = fbWallId;
                this.fbDirectId = fbPrivateId;
                this.customerId = customerId;
            this.LastCathyConversationId = lastCathyConversationId;
                this.lastUserAgentConversationId = lastUserAgentConversationId;
                this.createdDate = createdDate;
                this.updatedDate = updatedDate;
            }
        }
}