﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace CathyRestAPI.Models
{
    public class CathyForBanking
    {
        CathyRequest request;
        public static int conversationStage = 1;
        public string Intent = String.Empty;
        public CathyForBanking(CathyRequest request)
        {
            this.request = request;
            Task.Run(async () =>
            {
                Intent = await getIntent(request.RequestMessage);
            }).Wait();

        }

        static async Task<string> getIntent(string requestMessage)
        {
            using (var client1 = new HttpClient())
            {
                client1.BaseAddress = new Uri("https://api.projectoxford.ai");

                string id = "0430b2586cd44030bd176bced007fd60";//e32960c9-ebf6-4620-9312-94bc2e7b8aad
                string subscriptionKey = "0430b2586cd44030bd176bced007fd60";//131c04cfa92d48fcabc529deb75a44f6

                string requestUri = "";

                requestUri = "/luis/v2.0/apps/9d5c1190-4abf-4797-9d19-d3e3f2972bb1?subscription-key=" + subscriptionKey + "&q=" + requestMessage;

                HttpResponseMessage response = new HttpResponseMessage();
                response = await client1.GetAsync(requestUri);

                return JsonConvert.DeserializeObject<string>(await response.Content.ReadAsStringAsync());
                //return response;
            }
            //return "Hello" ;
        }

        public void CathyForBankingResponse()
        {

            switch (conversationStage)
            {
                case 1: Introduction();
                        break;
                case 2:  InvestmentAmount();
                        break;
                case 3: InvestmentPeriod();
                        break;
                case 4: LinkedAccount();
                        break;
                case 5: MonthlyInvestmentDate();
                        break;
                case 6: RedemptionInstruction();
                        break;
                case 7: RedemptionAccount();
                        break;
                case 8: Confirmation();
                        break;
                case 9: ConfirmationClosingRemarks();
                        break;

//           default :

            }


        }

        private void ConfirmationClosingRemarks()
        {
            throw new NotImplementedException();
        }

        private void Confirmation()
        {
            throw new NotImplementedException();
        }

        private void RedemptionAccount()
        {
            throw new NotImplementedException();
        }

        private void RedemptionInstruction()
        {
            throw new NotImplementedException();
        }

        private void MonthlyInvestmentDate()
        {
            throw new NotImplementedException();
        }

        private void LinkedAccount()
        {
            throw new NotImplementedException();
        }

        private void InvestmentPeriod()
        {
            throw new NotImplementedException();
        }

        private void InvestmentAmount()
        {
            throw new NotImplementedException();
        }

        private void Introduction()
        {
            throw new NotImplementedException();
        }



    }
}