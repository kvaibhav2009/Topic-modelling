﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class ConversationResponse
    {
        public string ConversationResponseId { get; set; }
        public string ConversationRequestId { get; set; }
        public string ResponseMessage { get; set; }
        public string ResponseAction { get; set; }
        public string AgentId { get; set; }
        public string TokenId { get; set; }

        public bool SMEReviewFeedback { get; set; }
        public DateTime CreatedDate { get; set; }

        public ConversationResponse(string conversationResponseId, string conversationRequestId, string responseMessage, string action, string agentId, string tokenId, bool smeFeedback, DateTime createdDate)
        {
            this.ConversationResponseId = conversationResponseId;
            this.ConversationRequestId = conversationRequestId;
            this.ResponseMessage = responseMessage;
            this.ResponseAction = action;
            this.AgentId = agentId;
            this.TokenId = tokenId;
            this.SMEReviewFeedback = smeFeedback;
            this.CreatedDate = createdDate;
        }



        public bool isAgentCommunicationOn()
        {
            return false;
        }


    }
}