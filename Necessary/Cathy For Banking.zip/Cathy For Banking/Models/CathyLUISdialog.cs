﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Builder.Dialogs;

namespace CathyRestAPI.Models
{
    public class CathyLUISdialog
    {

        public CathyRequest request = new CathyRequest();
        public string LUISreply = "Please retry";
        static string policynumber = string.Empty;

        public string LUISanswer = null;
        public bool responsereceived = false;
       public CathyLUISdialog(CathyRequest request)
       {
          this.request = request;
             
        }

        private class CathyQA
        {
            public string[] ColumnNames { get; set; }
            public string[,] Values { get; set; }

        }

        public async Task conversationswitch(String USERintent, CathyRequest request)
        {
            //String LUISreply = string.Empty;
            String query = request.RequestMessage;
            

            switch (USERintent)
            {
                case "None":
                    LUISreply = ResponseforNone(USERintent, request);
                    break;
                case "GeneralQAUtterence":
                    var t=await GetQAResponse(query);
                    break;
                case "GeneralQAUtternces":
                    t=await GetQAResponse(query);
                    break;
                case "GeneralPolicyQuery":
                    LUISreply = "You know, we are going green. All policy documents will be emailed to you";
                    break;
                case "greetingshelp":
                    LUISreply = "Am good, Thank you! How can I help you today?";
                    break;
                case "identifyproducttype":
                    LUISreply = identifyproducttype();
                    break;
                case "Productname":
                    await GetQAResponse(query);
                    break;
                case "talkwithagent":
                    LUISreply = "Thank you for your interest, we’ll connect you shortly to an agent";
                    break;
                case "generalgreetings":
                    LUISreply = "You’re welcome "+request.SenderName+"! Have a great day!";
                    break;
                case "PolicyChangeRequest":
                    LUISreply = policyChangeRequest();
                    break;
                case "ChangePolicy":
                    LUISreply = PolicyCancellationRequest();
                    break;
                case "PolicyCustomer":
                    LUISreply = "Great! I need your Zip Code as well please";
                    break;
                case "PolicyCancellationRequest":
                    LUISreply = PolicyCancellationRequest();
                    break;
                case "AutoPolicy":
                    LUISreply =autoPolicy();
                    break;
                case "Homepolicy":
                    LUISreply = homePolicy();
                    break;
                case "AgentPositiveResponse":
                    LUISreply = "Thank you for your interest, we’ll connect you shortly to an agent.";
                    break;
                case "AgentNegativeResponse":
                    LUISreply = "Thank you.Goodbye.";
                    break;
                case " ":
                    LUISreply = await processBlankIntent();
                    break;
                case "FindInstallmentDetails":
                    LUISreply = "In order to serve this question I need to move to you to private chat";
                    break;
                case "validatepolicydetails":
                    LUISreply = validatepolicydetails();
                    break;
                case "GeneralProductOffering":
                    LUISreply = "What kind of insurance policy are you looking for? We have Auto,Home Policy(s).";
                    break;
                

            }
            
            //return LUISreply;
        }

        private string identifyproducttype()
        {
            string query = request.RequestMessage;
            CathyDialogManager cathydialogmanager = new CathyDialogManager();
            string[] strquery = query.Split(' ');
            ArrayList arrproductNamelist = cathydialogmanager.getAllProductNames(query);
            if (arrproductNamelist.Count > 0)
            {
             LUISreply = "We have " + arrproductNamelist.Count.ToString() + " Product(s) available.We have " + arrproductNamelist[0].ToString() + "," + arrproductNamelist[1].ToString() + "  available.Choose any one to know more.";

            }
            else
            {

                LUISreply = "Sorry I don't have the requested information. An agent will get back to you shortly";
            }

            return LUISreply;

        }

        private string validatepolicydetails()
        {
            string query = request.RequestMessage;
            String[] details = query.Split(',');

            CathyDialogManager cathydialogmanager = new CathyDialogManager();
            ArrayList arraypolicydetails = cathydialogmanager.validatepolicydetails(details[1].Trim(), details[2].Trim(), details[3].Trim());

            if (arraypolicydetails.Count > 0)
            {

                LUISreply="Thanks" + details[1] + ",for the PolicyNumber:" + details[2] + ".A premium of " + arraypolicydetails[0].ToString() + " is due on " + arraypolicydetails[1].ToString().Split(' ')[0]+"";
            }
            else
            {
                LUISreply="Sorry I don't have the requested information. An agent will get back to you shortly";
            }
            return LUISreply;
            
        }

        private string autoPolicy()
        {
            string query = request.RequestMessage;
            try
            {
                CathyDialogManager cathydialogmanager = new CathyDialogManager();
                ArrayList arrproductNamelist = cathydialogmanager.getAllProductNames(query);
                if (arrproductNamelist.Count > 0)
                {
                    LUISreply = "We have " + arrproductNamelist.Count.ToString() + " auto policy product(s) available -  " + arrproductNamelist[0].ToString() + "," + arrproductNamelist[1].ToString() + " available.Which product would you like to know more?";
                }
                else
                {

                    LUISreply = "Sorry I don't have the requested information. An agent will get back to you shortly";
                }
            }
            catch (Exception e)
            {
                LUISreply = "Sorry I don't have the requested information. An agent will get back to you shortly";
            }

            return LUISreply;
        }


        private string homePolicy()
        {
            string query = request.RequestMessage;
            CathyDialogManager cathydialogmanager = new CathyDialogManager();
            ArrayList arrproductNamelist = cathydialogmanager.getAllProductNames(query);


            if (arrproductNamelist.Count > 0)
            {
                LUISreply = "We have " + arrproductNamelist.Count.ToString() + " home policy products - " + arrproductNamelist[0].ToString() + "," + arrproductNamelist[1].ToString() + " available.Which product would you like to know more?";

            }            
            else
            {

                LUISreply = "Sorry I don't have the requested information. An agent will get back to you shortly";
            }

            return LUISreply;

        }


        private async Task<string> processBlankIntent()
        {
            string query = request.RequestMessage;
            string strreplyFromDialog = "buy auto";
            string strreplyHome = "buy home";
            if (query.Contains(strreplyFromDialog))
            {

                try
                {
                    CathyDialogManager cathydialogmanager = new CathyDialogManager();
                    ArrayList productNameList = cathydialogmanager.getAllProductNames(query);

                    if (productNameList.Count > 0)
                        LUISreply = "We have " + productNameList.Count.ToString() + " auto policy product(s) available -  " + productNameList[0].ToString() + "," + productNameList[1].ToString() + " available.Which product would you like to know more?";
                    else
                        LUISreply = "Sorry I don't have the requested information. An agent will get back to you shortly";
                }
                catch (Exception e)
                {
                    LUISreply = "Sorry I don't have the requested information. An agent will get back to you shortly";

                }

            }
            else if (query.Contains(strreplyHome))
            {
                CathyDialogManager cathydialogmanager = new CathyDialogManager();
                ArrayList productNameList = cathydialogmanager.getAllProductNames(query);
                if (productNameList.Count > 0)
                    LUISreply = "We have " + productNameList.Count.ToString() + " home policy product(s) - " + productNameList[0].ToString() + "," + productNameList[1].ToString() + " available.Which product would you like to know more?";
                else
                    LUISreply = "Sorry I don't have the requested information. An agent will get back to you shortly";

            }
            else
            {
                string replyfromQA = string.Empty;
                 await GetQAResponse(query);
                replyfromQA = LUISreply;
                Console.WriteLine(replyfromQA);

                if (!string.IsNullOrEmpty(replyfromQA))
                {
                    LUISreply = replyfromQA;
                }
                else
                {
                    LUISreply = "Sorry I don't have the requested information. An agent will get back to you shortly";
                }

            }

            return LUISreply;


        }

        private string PolicyCancellationRequest()
        {

            if (request.IsPrivateMessage)
            {
                string query = request.RequestMessage;
                String[] details = query.Split(',');
                if (details.Count() == 3)
                {
                    String firstname = details[0];
                    String policynumber = details[1];
                    String zipcode = details[2];
                    CathyDialogManager cathydialogmanager = new CathyDialogManager();
                    ArrayList arraypolicydetails= cathydialogmanager.cancelpolicydetails(firstname, policynumber, zipcode);

                    if (arraypolicydetails.Count > 0)
                    {
                        LUISreply = "Thanks " + firstname + "!The policy " + policynumber + " is effective from " + arraypolicydetails[0].ToString().Split(' ')[0] + " and expires on " + arraypolicydetails[1].ToString().Split(' ')[0];
                    }
                    else
                    {
                        LUISreply = "Incorrect Details";
                    }
                }
                else
                {
                    LUISreply = "Can you please share your First Name,policy number and zip code in private chat?";

                }

            }
            else
            {
                LUISreply = " Can you please share your First Name,policy number and zip code in private chat?";
            }

           
            return LUISreply;
        }

        private string Changepolicy()
        {
            string query = request.RequestMessage;
            string LUISreply = string.Empty;
            string strwelcome = "That would be it";
            string strwelcomemessage = "that would be it";
            string strcontactnumber = "858 223 6754";

            if (query.Contains(strcontactnumber))
                LUISreply = "Cool. I will provide you a confirmation once we get the changes updated. Meanwhile anything else I can help you with?";
            else
            {
                if (query.Contains(strwelcome) || query.Contains(strwelcomemessage))
                    LUISreply = "You’re welcome " + request.SenderName + "! Have a great day!";
                else
                    LUISreply = "Sorry I don't have the requested information. An agent will get back to you shortly.";
            }
                return LUISreply;
        }

        private string policyChangeRequest()
        {
            string strpolicynumbersub = "policy number";
            string strPolicyNumber = "Policy Number";
            string strClaimNumber = "claim number";
            string query = request.RequestMessage;
                        
            string LUISreply = string.Empty;

            if ((query.Contains(strpolicynumbersub)) || (query.Contains(strPolicyNumber)) || (query.Contains(strClaimNumber) ))
            {
                LUISreply = "Got it! What have you provided as name of the policy holder?";
                policynumber = "A202";              
            }
            else
            {
                LUISreply = "Sure, I can help on that.Just need to verify a few details.Can you send me your policy number on a private chat?";

            }

            return LUISreply;

        }

        public String ResponseforNone(String USERintent, CathyRequest request)
        {
            string strCustomerName = "Bill Walters";
            string strZipcode = "49012";
            string query = request.RequestMessage;
            string LUISreply = string.Empty;
            if(request.IsPrivateMessage==true)
            {
                if (query.Contains(strCustomerName))
                {
                    LUISreply = "Great! I need your Zip Code as well please";

                }
                else if (query.Contains(strZipcode))
                {
                    LUISreply = "Thanks Bill! The policy A000000001 is effective from 01/01/2016 and expires on 01/01/2017. Your contact number on the policy is 858 223 4343. What would the new number be?";

                }
                else
                {
                    LUISreply = "Sorry I don't have the requested information. An agent will get back to you shortly";

                }
            }
            else
                LUISreply = "Please send that in a private converastion";
            return LUISreply;

        }

        private async Task<bool> GetQAResponse(string query)
        {
            string resultnew = string.Empty;
            String answer = string.Empty; ;

            using (var client = new HttpClient())
            {
                var scoreRequest = new
                {

                    Inputs = new Dictionary<string, CathyQA>() {
                        {
                            "input1",
                            new CathyQA()
                            {
                                ColumnNames = new string[] {"Query"},
                                Values = new string[,] {  { ""+ query }  }
                            }
                        },
                    },
                    GlobalParameters = new Dictionary<string, string>()
                    {
                    }
                };

                Console.WriteLine("The query is" + scoreRequest);

                const string apiKey = "Vpasiy83I4+gtITmqYA+/EjcD/j5T64xFrF0iD6vx+o6zIFTYNaXxQzfzmx877HUwv4UpCbJ+Jn44ftKHw1jpg=="; // Replace this with the API key for the web service
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/2a883d508ce542d0bf32563cfc5b61a6/services/65e6cdaeded04f2ca6541aec5fa25de8/execute?api-version=2.0&details=true");



                HttpResponseMessage response = await client.PostAsJsonAsync("", scoreRequest);

                if (response.IsSuccessStatusCode)
                {
                    resultnew = await response.Content.ReadAsStringAsync();
                    
                    JObject joResponse = JObject.Parse(resultnew);
                    JObject ojObject = (JObject)joResponse["Results"];
                    JObject jsonoutput = (JObject)ojObject["output1"];
                    JObject jsonvalue = (JObject)jsonoutput["value"];
                    JArray arrvalues = (JArray)jsonvalue["Values"];
                    JArray arrval = (JArray)arrvalues[0];
                    answer = arrval[1].ToString();

                }
                else
                {
                    Console.WriteLine(string.Format("The request failed with status code: {0}", response.StatusCode));

                    // Print the headers - they include the requert ID and the timestamp, which are useful for debugging the failure
                    Console.WriteLine(response.Headers.ToString());

                    string responseContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(responseContent);
                }

                if (answer == "We are a paperless organization. All documents and billing will be through email only.")
                {
                    answer = "You know, we are going green. All policy documents will be emailed to you";
                }


                LUISreply = answer;
                LUISanswer = answer;

                responsereceived = true;
               // request.RequestMessage = answer;

                //return answer;

                return true;
            }
        }

    }
}