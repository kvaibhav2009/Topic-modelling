﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public static class CathyConstants
    {
        public static string twitterChannel = "Twitter";
        public static string facebookChannel = "Facebook";

        public static string negativeSentiment = "Negative";
        public static string normalSentiment = "None";

        //these may not be required
        public static string isPrivateMessageTrue = "True";
        public static string isPrivateMessageFalse = "False";

        public static string sendToUser = "SendToUser";
        public static string sendToAgent = "SendToAgent";
        public static string sendToBoth = "SendToBoth";

        public static string noToken = "none";

        public static string defaultAgent = "1200262286685328"; //1308325892525145

        public static string defaultAgent_ConversationId = "t_mid.1468325353281:ee1b43e371a4811995"; //t_mid.1475756515117:4c5d145c842c5f5c49 



        //public static string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source="
        //        + "c:\\Users\\maria.lopes\\Documents\\CathyDB.mdb;User Id=admin;Password=;";

        public static string connectionString = String.Format("Server={0};Port={1};" +
                    "User Id={2};Password={3};Database={4};",
                    "127.0.0.1", "5432", "postgres",
                    "Acc1234$$", "postgres");

        public static string botURL = "BotURL";
        public static string botParam1 = "BotParam1";
        public static string botParam2 = "BotParam2";
    }
}