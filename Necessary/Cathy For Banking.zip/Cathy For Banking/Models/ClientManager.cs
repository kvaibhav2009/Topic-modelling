﻿using Npgsql;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class ClientManager
    {
        static DataAccess access = new DataAccess();

        [System.Web.Services.WebMethod]
        public static string setClient(string client)
        {
            string queryString = "update CLIENT_BOT set status = 't' where clientname = @client";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@client", SqlDbType.VarChar) { Value = client}
                
            };
            bool success = access.ExecuteNonQuery(queryString, CommandType.Text, sqlParams);
            string queryString1 = "update CLIENT_BOT set status = 'f' where clientname <> @client";
            NpgsqlParameter[] sqlParams1 = {
                new NpgsqlParameter("@client", SqlDbType.VarChar) { Value = client}

            };
            bool success1 = access.ExecuteNonQuery(queryString1, CommandType.Text, sqlParams1);
            if (success)
            {
                return client + " configuration is Active";
            }
            else
            {
                return client + " configuration not updated";
            }
            

        }

        public string getClient()
        {
            string clientId = null;
            string queryString = "select * from CLIENT_BOT where Status = 'y'";
            
            DataTable datatable = access.ExecuteSelectCommand(queryString, CommandType.Text);
            if (datatable.Rows.Count > 0)
            {
                clientId = datatable.Rows[0]["Client_ID"].ToString();
            }
            return clientId;
        }

        public IDictionary loadBotDetails(String clientId)
        {
         
            string queryString = "select * from CLIENT_BOT where Client_ID = @clientId";
            IDictionary botDetails = new Dictionary<string, string>();

            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@clientId", SqlDbType.VarChar) { Value = clientId}
            };

            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                botDetails.Add(CathyConstants.botURL,datatable.Rows[0]["BotServiceURL"].ToString());
                botDetails.Add(CathyConstants.botParam1, datatable.Rows[0]["BotAdditionalParam1"].ToString());
                botDetails.Add(CathyConstants.botParam2, datatable.Rows[0]["BotAdditionalParam2"].ToString());
            }
            return botDetails;
        }
    }

}