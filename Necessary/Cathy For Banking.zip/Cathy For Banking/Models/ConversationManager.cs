﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql;
using System.Data;
using System.Diagnostics;

namespace CathyRestAPI.Models
{
    public class ConversationManager
    {
        DataAccess access = new DataAccess();

        //public bool updateSentimentForConversation(String conversationId, String sentiment)
        //{
        //    string queryString = "update CATHY_CONVERSATION set FeedbackSentiment = @feedbackSentiment where conversationId = @conversationId and eoc = 't' and FeedbackSentiment is  null";
        //    NpgsqlParameter[] sqlParams = {
        //        new NpgsqlParameter("@feedbackSentiment", SqlDbType.VarChar) { Value = sentiment},
        //        new NpgsqlParameter("@conversationId", SqlDbType.VarChar) { Value = conversationId}
        //    };
        //    bool success = access.ExecuteNonQuery(queryString, CommandType.Text, sqlParams);
        //    return success;

        //}

        public bool updateEOCStatusForConversation(string conversationId, bool eocStatus)
        {
            string queryString = "update CATHY_CONVERSATION set EOC = @eocStatus where conversationId = @conversationId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@eocStatus", SqlDbType.Bit) { Value = eocStatus},
                new NpgsqlParameter("@conversationId", SqlDbType.VarChar) { Value = conversationId}
            };
            bool success = access.ExecuteNonQuery(queryString, CommandType.Text, sqlParams);
            return success;
        }

        public Conversation createConversation(string conversationId, string channel, string senderId, string parentPostId, String postId, bool isCathyConversation)
        {
            Conversation conversation = null;
            Console.WriteLine("the sender id " + senderId);
            DateTime createdDate = DateTime.Now;
            string queryString = "insert into CATHY_CONVERSATION (conversationId, channel, senderId, parentPostId, createdDate, updatedDate, isCathyConversation, clientID) values(@conversationId, @channel, @senderId, @parentPostId, @createdDate, @updatedDate,@isCathyConversation, @clientID)";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@conversationId", SqlDbType.VarChar) { Value = conversationId},
                 new NpgsqlParameter("@channel", SqlDbType.VarChar) { Value = channel },
                 new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId },
                 new NpgsqlParameter("@parentPostId", SqlDbType.VarChar) { Value = parentPostId },
                 new NpgsqlParameter("@isCathyConversation", SqlDbType.Bit) { Value = isCathyConversation },
                 new NpgsqlParameter("@createdDate",SqlDbType.DateTime) { Value = createdDate},
                 new NpgsqlParameter("@updatedDate",SqlDbType.DateTime) { Value = createdDate},
                 new NpgsqlParameter("@clientID",SqlDbType.VarChar) { Value = CathyRequestOrchestrator.clientId}

            };

            Console.WriteLine("the query string is " + queryString);
            bool success = access.ExecuteNonQuery(queryString, CommandType.Text, sqlParams);
            if (success == true)
            {
                conversation = new Conversation(conversationId, conversationId, senderId, parentPostId, null, null, createdDate, createdDate, isCathyConversation);
            }
            return conversation;
        }


        public ConversationRequest createConversationRequest(string conversationId, string postId, string sentiment, string requestMessage, bool isPrivateMessage)
        {
            string conversationRequestId = Guid.NewGuid().ToString();
            ConversationRequest conversationRequest = null;
            DateTime createdDate = DateTime.Now;
            string queryString = "insert into CATHY_CONVERSATION_REQUEST (conversationRequestId, conversationId, postId, requestMessage, sentiment, isPrivateMessage, createdDate) values(@conversationRequestId, @conversationId, @postId, @requestMessage, @sentiment, @isPrivateMessage, @createdDate)";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@conversationRequestId", SqlDbType.VarChar) { Value = conversationRequestId},
                new NpgsqlParameter("@conversationId", SqlDbType.VarChar) { Value = conversationId},
                 new NpgsqlParameter("@postId", SqlDbType.VarChar) { Value = postId },
                 new NpgsqlParameter("@requestMessage", SqlDbType.VarChar) { Value = requestMessage },
                 new NpgsqlParameter("@sentiment", SqlDbType.VarChar) { Value = sentiment },
                 new NpgsqlParameter("@isPrivateMessage",SqlDbType.Bit) { Value = isPrivateMessage},
                  new NpgsqlParameter("@createdDate",SqlDbType.DateTime) { Value = createdDate}

            };

            Console.WriteLine("the query string is " + queryString);
            bool success = access.ExecuteNonQuery(queryString, System.Data.CommandType.Text, sqlParams);
            if (success)
            {
                conversationRequest = new ConversationRequest(conversationRequestId, conversationId, postId, requestMessage, sentiment, isPrivateMessage, createdDate);
            }
            return conversationRequest;
        }

        public Conversation createConversation(UserProfile userprofile, string conversationId, string channel, string postId, string parentPostId, bool isPrivateMessage,
string sentiment, string requestMessage, bool isCathyConversation)
        {

            Console.WriteLine("the profile id in conv manager " + userprofile.UserProfileId);
            Conversation conversation = null;
            if(conversation == null)
            {
                Console.WriteLine("Creating conversation");
                string senderId = null;
                if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == true)
                {
                    senderId = userprofile.FbDirectId;
                }
                else if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == false)
                {
                    senderId = userprofile.FbWallId;
                }
                else if (channel.Equals(CathyConstants.twitterChannel))
                {
                    senderId = userprofile.TwitterId;
                }
                conversation = createConversation(conversationId, channel, senderId, parentPostId, postId, isCathyConversation);
            }

            return conversation;
        }


        public ConversationResponse createConversationResponse(string conversationRequestId, string responseMessage, string responseAction, string agentId, string tokenId)
        {
            ConversationResponse response = null;
            if (responseAction.Equals(CathyConstants.sendToAgent))
            {
                agentId = CathyConstants.defaultAgent;
            }
            else
            {
                agentId = "";
            }

            DateTime createdDate = DateTime.Now;
            string conversationResponseId = Guid.NewGuid().ToString();
            string queryString = "insert into CATHY_CONVERSATION_RESPONSE (ConversationResponseId, ConversationRequestId, ResponseMessage, ResponseAction, AgentId, TokenId) values(@ConversationResponseId, @conversationRequestId, @responseMessage,@responseAction, @agentId, @tokenId)";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@ConversationResponseId", SqlDbType.VarChar) { Value = conversationResponseId},
                new NpgsqlParameter("@conversationRequestId", SqlDbType.VarChar) { Value = conversationRequestId},
                 new NpgsqlParameter("@responseMessage", SqlDbType.VarChar) { Value = responseMessage },
                 new NpgsqlParameter("@responseAction", SqlDbType.VarChar) { Value = responseAction },
                 new NpgsqlParameter("@agentId", SqlDbType.VarChar) { Value = agentId },
                 new NpgsqlParameter("@tokenId", SqlDbType.VarChar) { Value = tokenId }

            };

            Console.WriteLine("the query string is " + queryString);
            bool success = access.ExecuteNonQuery(queryString, System.Data.CommandType.Text, sqlParams);
            if (success)
            {
                response = new ConversationResponse(conversationResponseId, conversationRequestId, responseMessage, responseAction, agentId, tokenId, false, createdDate);
            }
            Console.WriteLine("the success is " + success);
            return response;
        }

        public String generateTokenId(string senderId, string conversationRequestId)
        {
            string tokenId = senderId + conversationRequestId.Substring(0, 8);
            return tokenId;
        }




        public bool isConversationPresent(string conversationId)
        {

            string queryString = "select * from Cathy_Conversation where conversationId = @conversationId and isCathyConversation='t'";


            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@conversationId",SqlDbType.VarChar) { Value = conversationId},
            };

            Console.WriteLine("the conversation id " + conversationId + " query string "+queryString);
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            Console.WriteLine("the datatable " + datatable);
            if (datatable.Rows.Count > 0)
            {
                Console.WriteLine("Conversation is present");
                return true;
            }
            return false;
        }

        public Conversation getCathyConversation(String conversationId)
        {
            String sqlQuery = "select * from Cathy_Conversation where conversationId = @conversationId and isCathyConversation = 't'";
            return getConversation(conversationId, sqlQuery);
        }


        public Conversation getUserAgentConversation(String conversationId)
        {
            String sqlQuery = "select * from Cathy_Conversation where conversationId = @conversationId and isCathyConversation = 'f'";
            return getConversation(conversationId, sqlQuery);
        }

        public Conversation getConversation(String conversationId, String sqlQuery)
        {
            
            Conversation conversation = null;

            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@conversationId",SqlDbType.VarChar) { Value = conversationId},
            };

            DataTable datatable = access.ExecuteParamerizedSelectCommand(sqlQuery, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                string channel = datatable.Rows[0]["Channel"].ToString();
                string senderId = datatable.Rows[0]["SenderId"].ToString();
                string parentPostId = datatable.Rows[0]["ParentPostId"].ToString();
                string conversationStatus = datatable.Rows[0]["ConversationStatus"].ToString();
                string conversationSkillType = datatable.Rows[0]["ConversationSkillType"].ToString();
                string conversationMode = datatable.Rows[0]["ConversationMode"].ToString();
                string conversationAgentId = datatable.Rows[0]["ConversationAgentId"].ToString();
                bool isCathyConversation = (bool)(datatable.Rows[0]["isCathyConversation"]);
                DateTime createdDate = Convert.ToDateTime(datatable.Rows[0]["CreatedDate"]);
                DateTime updatedDate = Convert.ToDateTime(datatable.Rows[0]["UpdatedDate"]);
                conversation = new Conversation(conversationId, channel, senderId, parentPostId, conversationStatus, conversationSkillType, conversationMode, conversationMode, createdDate, createdDate, isCathyConversation);
            }
            return conversation;
        }

        public ConversationRequest getConversationRequest(String conversationId)
        {
            // string queryString = "select * from Cathy_Conversation_Request where conversationId = @conversationId";
            string queryString = "SELECT tt.* FROM Cathy_Conversation_Request tt " +
                                 "INNER JOIN " +
                                 "(SELECT conversationId, MAX(createdDate) AS MaxDateTime " +
                                 "FROM Cathy_Conversation_Request " +
                                 "GROUP BY conversationId) groupedtt " +
                                 "ON tt.conversationId = groupedtt.conversationId " +
                                 "AND tt.createdDate = groupedtt.MaxDateTime and tt.conversationId = @conversationId";
            ConversationRequest conversationRequest = null;

            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@conversationId",SqlDbType.VarChar) { Value = conversationId},
            };

            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                string conversationRequestId = datatable.Rows[0]["ConversationRequestId"].ToString();
                string conversationId_1 = datatable.Rows[0]["ConversationId"].ToString();
                string postId = datatable.Rows[0]["PostId"].ToString();
                string requestMessage = datatable.Rows[0]["RequestMessage"].ToString();
                string sentiment = datatable.Rows[0]["Sentiment"].ToString();
                bool isPrivateMessage = (bool)(datatable.Rows[0]["IsPrivateMessage"]);
                DateTime createdDate = Convert.ToDateTime(datatable.Rows[0]["CreatedDate"]);
                conversationRequest = new ConversationRequest(conversationRequestId, conversationId,postId, requestMessage, sentiment, isPrivateMessage, createdDate);
            }
            return conversationRequest;
        }

        public string getConversationResponseToken(String conversationRequestId)
        {
             string queryString = "select * from Cathy_Conversation_Response where conversationRequestId = @conversationRequestId";
            string token = null;
           

            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@conversationRequestId",SqlDbType.VarChar) { Value = conversationRequestId},
            };

            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                 token = datatable.Rows[0]["tokenid"].ToString();
            }
            return token;
        }

        public ConversationResponseFeedback createConversationResponseFeedback(string conversationId, string conversationResponseId, string postId )
        {
            ConversationResponseFeedback responseFeedback = null;
            DateTime createdDate = DateTime.Now;
            string feedbackId = Guid.NewGuid().ToString();
            string queryString = "insert into CATHY_CONVERSATION_RESPONSE_FEEDBACK (FeedbackId, ConversationId, ConversationResponseId, PostId, CreatedDate) values(@FeedbackId, @ConversationId, @ConversationResponseId,@PostId, @CreatedDate)";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@FeedbackId", SqlDbType.VarChar) { Value = feedbackId},
                new NpgsqlParameter("@ConversationId", SqlDbType.VarChar) { Value = conversationId},
                 new NpgsqlParameter("@ConversationResponseId", SqlDbType.VarChar) { Value = conversationResponseId },
                 new NpgsqlParameter("@PostId", SqlDbType.VarChar) { Value = postId },
                 new NpgsqlParameter("@CreatedDate", SqlDbType.DateTime) { Value = createdDate }
                 

            };

            Console.WriteLine("the query string is " + queryString);
            bool success = access.ExecuteNonQuery(queryString, System.Data.CommandType.Text, sqlParams);
            if (success)
            {
                responseFeedback = new ConversationResponseFeedback(feedbackId, conversationId, conversationResponseId,postId, createdDate);
            }
            Console.WriteLine("the success is " + success);
            return responseFeedback;
        }

        public ConversationFeedbackSentiment createConversationSentimentFeedback(string conversationId, string requestId, string responseId, string sentimentValue)
        {
            ConversationFeedbackSentiment conversationSentimentFeedback = null;
            DateTime createdDate = DateTime.Now;
            string feedbackId = Guid.NewGuid().ToString();
            string queryString = "insert into CATHY_CONVERSATION_SENTIMENTFEEDBACK (FeedbackId, ConversationId, RequestId, ResponseId, FeedbackSentiment, CreatedDate, FeedbackGivenBy) values(@FeedbackId, @ConversationId,@RequestId, @ResponseId,@FeedbackSentiment, @CreatedDate,@FeedbackGivenBy )";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@FeedbackId", SqlDbType.VarChar) { Value = feedbackId},
                new NpgsqlParameter("@ConversationId", SqlDbType.VarChar) { Value = conversationId},
                new NpgsqlParameter("@RequestId", SqlDbType.VarChar) { Value = requestId},
                 new NpgsqlParameter("@ResponseId", SqlDbType.VarChar) { Value = responseId },
                 new NpgsqlParameter("@FeedbackSentiment", SqlDbType.VarChar) { Value = sentimentValue },
                 new NpgsqlParameter("@CreatedDate", SqlDbType.DateTime) { Value = createdDate },
                 new NpgsqlParameter("@FeedbackGivenBy", SqlDbType.VarChar) { Value = "Customer" }


            };

            Console.WriteLine("the query string is " + queryString);
            bool success = access.ExecuteNonQuery(queryString, System.Data.CommandType.Text, sqlParams);
            if (success)
            {
                conversationSentimentFeedback = new ConversationFeedbackSentiment(feedbackId, conversationId, requestId, responseId, sentimentValue, createdDate, "Customer");
                updateEOCStatusForConversation(conversationId, false);
            }
            Console.WriteLine("the success is " + success);
            return conversationSentimentFeedback;
        }

    }
}