﻿using CathyOmniChannelRestClient;
using UtilityClasses;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.EnterpriseServices;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;
using System.Web.SessionState;
using static CathyOmniChannelRestClient.CathyBanking;

namespace CathyRestAPI.Models
{

    public class CathyBanking
    {
        CathyRequest request;
        public static string conversationStage = "1";
        public string Intent = String.Empty;
        public CathyForBankingResponse bankingresponse = null;
        static DataAccess access = new DataAccess();
        
        public static string reply = string.Empty;
        
        public int dialogseq = 0;

        int x = 0;
        
        public static HttpSessionState Session = System.Web.HttpContext.Current.Session; // { get; }

        public static HttpContext context = HttpContext.Current;
        
        public CathyBanking(CathyRequest request)
        {
            this.request = request;
            Task.Run(async () =>
            {
                bankingresponse = await getIntent(request.RequestMessage);
            }).Wait();

        }

        static async Task<CathyForBankingResponse> getIntent(string requestMessage)
        {
            using (var client1 = new HttpClient())
            {
                client1.BaseAddress = new Uri("https://api.projectoxford.ai");

                string id = "a0d3627a-4643-4839-8112-78bf550dfc5e";//EnhanceCFB=>f657a03a-12d1-4296-8d70-f521bbabf699 //CFB=>9d5c1190-4abf-4797-9d19-d3e3f2972bb1
                string subscriptionKey = "0430b2586cd44030bd176bced007fd60";//0430b2586cd44030bd176bced007fd60

                string requestUri = "";

                requestUri = "/luis/v2.0/apps/"+id+"?subscription-key=" + subscriptionKey + "&q=" + requestMessage;

                HttpResponseMessage response = new HttpResponseMessage();
                response = await client1.GetAsync(requestUri);

                return JsonConvert.DeserializeObject<CathyForBankingResponse>(await response.Content.ReadAsStringAsync());
                //return response;
            }
            //return "Hello" ;
        }

        public void CathyForBankingSwitch()
        {
            //conversationStage = getConversationStage(request.SenderId);
            //SessionManager.setSession("conversationStage", "1");


            Intent = bankingresponse.topScoringIntent.intent;
            dialogseq = getdialogseq(request.SenderId);


            /*
            var builder = require('botbuilder');

            var connector = new builder.ConsoleConnector().listen();
            var bot = new builder.UniversalBot(connector);
            */

            /*

            //int i = 1;
            int i;
            

            x++;
            //reply=""+x;
            



            if(Session["someKey"] == null)
                Session["someKey"] = 1;

            if (Session != null)
            {
                
                i =(int)Session["someKey"];
                i++;
                Session["somekey"] = i;
                reply = ""+i;
            }
            */

            //context.ConversationData.TryGetValue("value", out x);

            //context = ActivationContext.;
            //IDialogContext context = null;

            /*Task.Run(async () =>
             {
                 bool b= await TempVariables(context);
             }).Wait();

            //HttpContent.
            
            //HttpContext.Current.Session["MyKey"] = i;*/

            if (dialogseq != 0)
            {
                switch (Intent)
                {
                    case "InvestmentforRD": dialogseq = 2; break;
                    case "InvestGivenAmount": dialogseq = 3; break;
                    case "InvestmentPeriodAgreed": dialogseq = 4; break;
                    case "InvestmentROIAgreed": dialogseq = 5; break;
                    case "InvestmentROIdisagreed": dialogseq = 6; break;
                    //case "SalariedAccount": dialogseq = 6; break;
                    //case "SavingsAccount": dialogseq = 6; break;
                    case "InvestmentDayOfMonth":dialogseq = 7;break;
                    //case "Number": dialogseq = 9; break;

                }

            }


            if (Intent == "AccountBalance")
            {
                if (dialogseq == 0)
                 StartConversation();
                
                AccountBalanceEnquiry();


                return;
            }
               

            switch (dialogseq)
            {
                case 0:
                    StartConversation();
                    break;
                case 1:
                    Introduction();
                    break;
                case 2:
                    InvestmentforRD();
                    break;
                case 3:
                    InvestGivenAmount();
                    break;
                case 4:
                    InvestmentPeriodAgreed();
                    break;
                case 5:
                    InvestmentROIAgreed();
                    break;
                case 6:
                    LinkedAccount();
                    break;
                case 7:
                    InvestmentDayOfMonth();
                    break;
                case 8:
                    ChooseOption();
                    break;
                case 9:
                    RedemptionAccount();
                    break;
                case 10:
                    OTPConfirmation();
                    break;
                case 11:
                    ConfirmationclosingRemarks();   ///earlier 10
                    break;

                    //  default :
                    
            }
            

        }

        private void AccountBalanceEnquiry()
        {
            string accounttype = string.Empty;
            GetUserProfile userprofile = new GetUserProfile();
            string accountbalance = string.Empty;

            foreach (Entities2 entityreceived in bankingresponse.entities)
            {
                if (entityreceived.type == "AccountType")
                {
                    accounttype = entityreceived.entity;
                    
                }
            }


            CathyOmniChannelRestClient.CathyBanking.customerGeneric customer = new CathyOmniChannelRestClient.CathyBanking.customerGeneric();
            customer.customerId = "john";
            userprofile.customer = customer;
            if (accounttype == "salary")
                userprofile.accountType = "SALARIED";
            else
                userprofile.accountType = "SAVINGS";

            RootObject CustomerDetailsResponse = CathyOmniChannelAdaptor.getUserProfile(userprofile);
            List<AccountList> AccNumberList = CustomerDetailsResponse.customer.accountList;

            List<string> accountBalance = AccNumberList.Select(o => o.accountBalance).ToList();
            foreach (String acnBalance in accountBalance)
            {
                // return acnNumber;
                accountbalance = acnBalance;
            }

            reply = "Ok, let me check.Your current balance in Savings Account is USD "+accountbalance+". ";
            
        }

        static async Task<bool> TempVariables(IDialogContext context)
        {
            int i = 1;
            int x = 1;
            if (x == 0)
                context.ConversationData.SetValue("value", i);
            else
            {
                context.ConversationData.TryGetValue("value", out x);
                x++;
                context.ConversationData.SetValue("value", i);
            }

            reply = "" + x;

            

            return true;
        }
        
        private void OTPConfirmation()
        {
            AuthenticateOTP OTP = new AuthenticateOTP();
            OTP.otp = request.RequestMessage;
            OTP.jSessionId = request.SenderId;
            
            CathyOmniChannelRestClient.CathyBanking.customerGeneric customer = new CathyOmniChannelRestClient.CathyBanking.customerGeneric();
            customer.customerId = "john";
            OTP.customer = customer;
            
            cathyResponse exitcode=CathyOmniChannelAdaptor.authenticateOTP(OTP);

            if (exitcode.exitCode.Contains("OK"))
            {
                Investment Investmentobject = extractEntity(request.SenderId);

                NewInvestment newinvestment = new NewInvestment();
                newinvestment.investment = Investmentobject;
                exitcode = CathyOmniChannelAdaptor.validateNewInvestment(newinvestment);

                if ((exitcode.exitCode).Contains("OK"))
                {
                    exitcode = CathyOmniChannelAdaptor.createNewInvestment(newinvestment);
                    reply = " #eoc# Your product – Recurring Deposit Super Savings Account has been created.  You will now be transitioned to confirmation screen where you can see the details of your product which has been created.  Thank you for chatting with me.  Have a wonderful day.";

                }
                else
                {
                    reply = exitcode.exitCode;
                    //dialogseq = 1;
                }
                incrementdialogseq(request.SenderId);
            }
            else
            {
                
                reply = "#OTP# "+exitcode.exitCode+" Resending an OTP";
                
            }
           
        }

        private void ConfirmationclosingRemarks()
        {
            if ((Intent.Equals("ConfirmAndClose")) || (Intent.Equals("Yes")))
            {
             /*   Investment Investmentobject = extractEntity(request.SenderId);

                NewInvestment newinvestment = new NewInvestment();
                newinvestment.investment = Investmentobject;
                cathyResponse exitcode= CathyOmniChannelAdaptor.validateNewInvestment(newinvestment);


                if ((exitcode.exitCode).Contains("OK"))
                    exitcode = CathyOmniChannelAdaptor.createNewInvestment(newinvestment);

                reply = exitcode.exitCode;*/
                
                cleandialogseq(request.SenderId);
                cleanentity();

            }
        }

        public void cleanentity()
        {

            String commandString = "delete from investmentdetails";
             NpgsqlParameter[] sqlParams1 = { };
            bool success = access.ExecuteNonQuery(commandString, CommandType.Text,sqlParams1);
        }

        private Investment extractEntity(string senderId)
        {
            string queryString = "select * from investmentdetails where senderId = @senderId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
            };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            int c = 0;

            int investmentamount = 0;
            int duration = 0;
            string accounttype = string.Empty;
            int dayofmonth = 0;
            string redemptionaccounttype = string.Empty;
            string actionOnmaturity = string.Empty;
            string accountnumber = string.Empty;

            if (datatable.Rows.Count > 0)
            {
                investmentamount =Convert.ToInt32((datatable.Rows[0]["investmentamount"]));
                duration = Convert.ToInt32((datatable.Rows[0]["duration"]));
                dayofmonth = Convert.ToInt32((int)(datatable.Rows[0]["dayofmonth"]));
                accounttype = (string)datatable.Rows[0]["accounttype"];
                redemptionaccounttype = (string)datatable.Rows[0]["redemptionaccounttype"];
                actionOnmaturity=(string)datatable.Rows[0]["actionOnmaturity"];
            }

            reply = "Find the entities given investmentamount: " + investmentamount + "duration: " + duration + " dayofmonth "+ dayofmonth + " accounttype " + accounttype + " redemptionaccounttype " + redemptionaccounttype;

            Investment Investmentobject = new Investment();

            DateTime currentDate= DateTime.Now;
            GetUserProfile userprofile = new GetUserProfile();
            
            
            CathyOmniChannelRestClient.CathyBanking.customerGeneric customer = new CathyOmniChannelRestClient.CathyBanking.customerGeneric();
            customer.customerId = "john";
            userprofile.customer = customer;
            if (accounttype == "SalariedAccount")
                userprofile.accountType = "SALARIED";
            else
                userprofile.accountType = "SAVINGS";


            RootObject CustomerDetailsResponse = CathyOmniChannelAdaptor.getUserProfile(userprofile);

            List<AccountList> AccNumberList = CustomerDetailsResponse.customer.accountList;
            List<string> accountNumber = AccNumberList.Select(o => o.accountNumber).ToList();
            foreach (String acnNumber in accountNumber)
            {
                // return acnNumber;
                accountnumber = acnNumber;
            }


            //accountnumber = CathyOmniChannelAdaptor.getUserProfile(userprofile);

            
            Investmentobject.investmentAmount = investmentamount.ToString();
            Investmentobject.interestRate = 10;
            Investmentobject.actionOnMaturity = actionOnmaturity;// actionOnmaturity;
            Investmentobject.accountNumber = accountnumber;
            Investmentobject.accountType = "Recurring Deposit";
            Investmentobject.investmentBeneficiary = request.SenderName;
            Investmentobject.liquidateInAccount = "067610108308";
            Investmentobject.maturityAmount = ReturnOnInvestment.maturityAmount(investmentamount,duration);
            Investmentobject.maturityDate = ReturnOnInvestment.maturityDateFinder(duration);


            return Investmentobject;
        }

        private void RedemptionAccount()
        {
            if ((Intent == "SalariedAccount") || (Intent== "AmountTransferedtoSalariedAccount") || (Intent=="Yes"))
            {     // temp session value of "Salary account"
                insertRedemptionAccount("SalariedAccount");
                reply = "Your product – Recurring Deposit Super Savings Account has been created.  You will now be transitioned to confirmation screen where you can see the details of your product which has been created.  Thank you for chatting with me.  Have a wonderful day.";
                incrementdialogseq(request.SenderId);
            }
            
            if ((Intent == "SavingsAccount") || (Intent == "AmountTransferedtoSavingsAccount"))
            {    // temp session value of "SavingsAccount"
                insertRedemptionAccount("SavingsAccount");
                reply = "Your product – Recurring Deposit Super Savings Account has been created.  You will now be transitioned to confirmation screen where you can see the details of your product which has been created.  Thank you for chatting with me.  Have a wonderful day.";
                incrementdialogseq(request.SenderId);
            }
            reply = "#OTP# Based on the information provided by you, I have updated all the required information.  The system has sent you the OTP for confirmation, can you please type in the OTP in the chat window below";
             //C=10;

        }

        private void insertRedemptionAccount(string redemptionaccounttype)
        {
            string senderId = request.SenderId;
            string commandString = "update investmentdetails set redemptionaccounttype=@redemptionaccounttype where senderid=@senderId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                new NpgsqlParameter("@redemptionaccounttype", SqlDbType.VarChar) { Value = redemptionaccounttype}

            };

            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams);
        }

        private void InvestmentDayOfMonth()
        {
            string dayofMonth = string.Empty;
            if ((Intent == "InvestmentDayOfMonth") || (Intent=="None"))
            {
                foreach (Entities2 entityreceived in bankingresponse.entities)
                {
                    if (entityreceived.type == "DayOfMonth")
                    {
                        dayofMonth = entityreceived.entity;
                        incrementdialogseq(request.SenderId);
                    }
                }

                if (dayofMonth == string.Empty)
                {
                    foreach (Entities2 entityreceived in bankingresponse.entities)
                    {
                        if (entityreceived.type == "builtin.ordinal")
                        {
                            dayofMonth = entityreceived.entity;
                            incrementdialogseq(request.SenderId);
                        }
                    }

                }
                reply = "Ok two more questions only to open the account – For redemption – there are 2 options.Choose either of them.Option 1 – On the Redemption date, the account would be closed and the amount(Principle + interest) would be transferred to your linked account.Option 2 - On the Redemption date, the account would be closed and the amount (Principle + interest) would be converted to Term Deposit with same investment period and the rate of interest prevailing on that redemption date.";
               
            }
            if (Intent == "Number")
            {
                foreach (Entities2 entityreceived in bankingresponse.entities)
                {
                    if (entityreceived.type == "numericvalue")
                    {
                        dayofMonth = entityreceived.entity;
                        incrementdialogseq(request.SenderId);
                    }
                }
                
            }


            String dom = Regex.Replace(dayofMonth, "[^0-9]+", string.Empty);
            dom = extractNumber(dom);
            int dayOfMonthno = Convert.ToInt32(dom);
            updateDayOfMonth(dayOfMonthno);


            //increment the value of C; C=8;

        }

        private void updateDayOfMonth(int dayofmonth)
        {
            string senderId = request.SenderId;
            string commandString = "update investmentdetails set dayofmonth=@dayofmonth where senderid=@senderid";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                new NpgsqlParameter("@dayofmonth", SqlDbType.Int) { Value = dayofmonth}

            };

            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams);
        }

        private string extractNumber(string str)
        {
            StringBuilder builder = new StringBuilder();
            char a;
            int x = 0;

            for (int i = 0; i < str.Length; i++)
            {
                if (Char.IsDigit(str[i]))
                {
                    //builder.Append(x).Append(str[i]);
                    a = (char)str[i];
                    builder.Append(a);

                }

            }
            str = builder.ToString();

            return str;
        }

        private int getdialogseq(String senderId)
        {
            string queryString = "select * from conversationstage where SenderId = @senderId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
            };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            int c = 0;
            if (datatable.Rows.Count > 0)
            {
                c = (int)(datatable.Rows[0]["stage"]);

            }
            return c;

        }

        private void InvestmentROIAgreed()
        {
            string ROI = string.Empty;
            if (Intent == "InvestmentROIAgreed" || Intent == "Yes")
            {
                reply = "Right then, " + request.SenderName + ", You have a salary account and a savings account, from which account do you want us to transfer money to your Recurring Deposit Super Savings Account every month?";
                //increment the value of C; C=6;
                string commandString = "update investmentdetails set duration=36 where senderid=@senderid and duration<36";
                InsertInvestmentPeriod(36, commandString);
                incrementdialogseq(request.SenderId);
            }


        }

        private void InvestmentPeriodAgreed()
        {
            string duration = string.Empty;
            int durationno = 1;
            if (Intent == "InvestmentPeriodAgreed")
            {
                //copy the entity duration
                foreach (Entities2 entityreceived in bankingresponse.entities)
                {
                    if (entityreceived.type == "Duration")
                    {
                        duration = entityreceived.entity;
                        incrementdialogseq(request.SenderId);
                        break;
                    }
                }

                
                Regex.Replace(duration, "[^0-9]+", string.Empty);
                durationno = Convert.ToInt32(extractNumber(duration)); ;
                reply = "Ok, for " + duration + " months you will earn 4% rate of interest, we have a special rate of 5% rate of interest for investments up to or beyond 36 months, do you want to consider them? ";
                //increment the value of c//C=5
                string commandString = "update investmentdetails set duration=@duration where senderid=@senderid";
                InsertInvestmentPeriod(durationno, commandString);

            }
            

        }

        private void InsertInvestmentPeriod(int duration,string commandString)
        {
            string senderId = request.SenderId;
            
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                new NpgsqlParameter("@duration", SqlDbType.Int) { Value = duration}

            };

            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams);
        }

        private void InvestGivenAmount()
        {
            String Amount = "200";
           
            if ((Intent == "InvestGivenAmount") || (Intent=="Yes") )
            {  //Copy the entity investment amount and ROI agreed
                foreach (Entities2 entityreceived in bankingresponse.entities)
                {
                    if (entityreceived.type == "Amount")
                    {
                        Amount = entityreceived.entity;

                        break;
                    }

                }
                Regex.Replace(Amount, "[^0-9]+", string.Empty);
                //string amt = Amount;
                
                int amt = Convert.ToInt32(extractNumber(Amount));


                reply = "Right then, How many months do you want to invest the specified amount " + amt + " for? ";
                incrementdialogseq(request.SenderId);
                
                InsertInvestmentAmount(amt);
                return;
            }
            if (Intent == "InvestmentNotWorthy")
            {
                reply = "Canceling your request";
                return;
            }


        }




        public void StartConversation()
        {
            reply = "Hello " + request.SenderName + ".I'm AI Cognitive Assistant Cathy. Congratulations on successfully getting your Agreement in Principle!You're a big step closer to being able to buy your product – Recurring Deposit Super Savings Account.Now we need to talk the options that you can explore.I will ask you a few questions, and your answers will enable me to create the product for you.Are you ready to get started ?";
            //Adddialogseq C=1
            startdialogseq(request.SenderId);
            InsertInvestmentdetails(request.SenderId);
        }

        private void InsertInvestmentdetails(string senderId)
        {
            int i = 1;
            string commandString = "insert into investmentdetails values (@senderId ,null,null,null,null,null) ";
            NpgsqlParameter[] sqlParams1 = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                 new NpgsqlParameter("@conversationdialogstage", SqlDbType.Int) { Value = i}
                };
            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams1);
        }

        private void startdialogseq(string senderId)
        {
            int i = 1;
            string commandString = "insert into conversationstage values (@senderId , @conversationdialogstage) ";
            NpgsqlParameter[] sqlParams1 = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                 new NpgsqlParameter("@conversationdialogstage", SqlDbType.Int) { Value = i}
                };
            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams1);

        }

        private void incrementdialogseq(string senderId)
        {
            int i = dialogseq;
            i++;
            String commandString = "update conversationstage set stage = @conversationdialogstage where senderId = @senderId";
            NpgsqlParameter[] sqlParams1 = {
                     new NpgsqlParameter("@conversationdialogstage", SqlDbType.Int) { Value = i},
                     new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
                };
            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams1);
            if (success)
            {
                dialogseq = i;
            }

        }

        public void cleandialogseq(string senderId)
        {
            int i = dialogseq;
            i++;
            String commandString = "delete from conversationstage";
            NpgsqlParameter[] sqlParams1 = {
                     new NpgsqlParameter("@conversationdialogstage", SqlDbType.Int) { Value = i},
                     new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
                };
            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams1);
            if (success)
            {
                dialogseq = i;
            }

        }

        public void IncrementconversationStage()
        {
            string conversationStage = SessionManager.getSession("conversationStage");
            char c = conversationStage[0];
            int i = (int)c;
            conversationStage = "" + i++;
            SessionManager.setSession("conversationStage", conversationStage);
        }

        public int getConversationStage(string senderId)
        {

            int stage = 0;
            string queryString = "select * from conversationstage where senderId = @senderId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
            };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);

            if (datatable.Rows.Count > 0)
            {
                stage = (int)(datatable.Rows[0]["senderId"]);

            }

            return stage;
        }

        
        private void ChooseOption()
        {
            if ((Intent.Equals("Option1Chosen")))
            {
                // send the option
                actionOnmaturity("Redeem");
                reply = "Ok, last question – Do you want the redemption amount transferred to your linked account";
                incrementdialogseq(request.SenderId); //C=9;
            }


            if ((Intent.Equals("Option2Chosen")))
            {
                // send the option
                actionOnmaturity("TERMDEPOSIT");
                reply = "Ok, last question – Do you want the redemption amount transferred to your linked account";
                incrementdialogseq(request.SenderId); //C=9;
            }
            

        }

        private void actionOnmaturity(string actionOnmaturity)
        {
            string senderId = request.SenderId;
            string commandString = "update investmentdetails set actionOnmaturity=@actionOnmaturity where senderid=@senderid";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                new NpgsqlParameter("@actionOnmaturity", SqlDbType.VarChar) { Value = actionOnmaturity}

            };

            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams);
        }

        private void LinkedAccount()
        {
            if (Intent.Equals("SalariedAccount") || Intent.Equals("Yes"))
            {              // temp session value of "Salary account"

                InsertchosenAccountType("SalariedAccount");
            }
            if ((Intent == "SavingsAccount") || (Intent== "AmountTransferedtoSavingsAccount"))
            {    // temp session value of "SavingsAccount"
                InsertchosenAccountType("SavingsAccount");
            }
            reply = "Right then, on which date of every month do you want to have the amount transferred to your investment account?";
            incrementdialogseq(request.SenderId); //C=7;

        }

        private void InsertchosenAccountType(string accounttype)
        {
            string senderId = request.SenderId;
            string commandString = "update investmentdetails set accounttype=@accounttype where senderid=@senderid";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                new NpgsqlParameter("@accounttype", SqlDbType.VarChar) { Value = accounttype}

            };

            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams);
        }

        private void InvestmentPeriod()
        {
            throw new NotImplementedException();
        }

        private void InvestmentforRD()
        {

            if ((Intent.Equals("InvestmentforRD")) || (Intent.Equals("Yes")))
            {
                reply = "Would you like to invest $200 every month which is based on 25 % of your average balance of amount available in your salary account(main account) at the end of every month?";
                incrementdialogseq(request.SenderId);//increment the value of C;//C=3;

            }
            

        }

        private void InsertInvestmentAmount(int investmentamount)
        {
            string senderId = request.SenderId;
            string commandString = "update investmentdetails set investmentamount=@investmentamount where senderid=@senderid";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                new NpgsqlParameter("@investmentamount", SqlDbType.Int) { Value = investmentamount}

            };

            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams);

            
        }

        private void Introduction()
        {
            switch (Intent)
            {
                case "CreateRecurringDeposit":
                    reply = "Ok," + request.SenderName + ", let's get started. Recurring Deposit Super Savings Account would require you to invest a defined amount every month.";
                    //increment the value of C //C=2
                    incrementdialogseq(request.SenderId);
                    break;
                case "SkipRDcreation":
                    reply = "Ok thanks #eoc#";
                    terminateConversation();
                    break;
                case "Yes":
                    reply = "Ok," + request.SenderName + ", let's get started. Recurring Deposit Super Savings Account would require you to invest a defined amount every month.";
                    incrementdialogseq(request.SenderId);//increment the value of C //C=2
                    break;
                case "Negative":
                    reply = "Ok thanks #eoc#";
                    break;
            }

        }

        private void terminateConversation()
        {
            cleandialogseq(request.SenderId);
            cleanentity();

        }
    }
}