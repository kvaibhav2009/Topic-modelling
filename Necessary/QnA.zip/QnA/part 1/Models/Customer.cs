﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql;
using System.Data;

namespace CathyRestAPI.Models
{
    public class Customer
    {

        string customerId { get; set;  }
        string firstname { get; set; }
        string lastname { get; set; }
        string twitterId { get; set; }
        string fbWallPostId { get; set; }
        string fbPrivateMsgId { get; set; }
        DateTime dob { get; set; }
        string email { get; set; }
        string phoneNumber { get; set; }
        string addr1 { get; set; }
        string addr2 { get; set; }
        string city { get; set; }
        string state { get; set; }
        string zip { get; set; }
        string country { get; set; }

        public string getCustomerId(string senderId, string channel, bool isPrivateMessage)
        {
            String queryString = null;
            DataAccess access = new DataAccess();
            string retrievedCustomerId = null;
            if (channel.Equals(CathyConstants.twitterChannel))
            {
                queryString = "SELECT * from CUSTOMER where Twitter_UserId = @senderId;";
            }
            else if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == false)
            {
                queryString = "SELECT * from CUSTOMER where Facebook_WallUserId = @senderId;";
            }
            else if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == true)
            {
                queryString = "SELECT * from CUSTOMER where Facebook_DirectUserId = @senderId;";
            }
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
            };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                retrievedCustomerId = datatable.Rows[0]["Customer_ID"].ToString();
            }

                return retrievedCustomerId;
        }
    }
}