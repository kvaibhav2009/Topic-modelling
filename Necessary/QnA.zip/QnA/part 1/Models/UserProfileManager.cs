﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql;
using System.Data;
using System.Collections;

namespace CathyRestAPI.Models
{
    public class UserProfileManager
    {
        DataAccess access = new DataAccess();

        //retrieves an existing user profile
        public UserProfile getUserProfile(string senderId, string channel, bool isPrivateMessage)
        {
            string queryString = prepareQueryString(channel, isPrivateMessage);


            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId",SqlDbType.VarChar) { Value = senderId},
                  new NpgsqlParameter("@clientID",SqlDbType.VarChar) { Value = CathyRequestOrchestrator.clientId}
            };

            Console.WriteLine(queryString);
            Console.WriteLine("the sender id " + senderId);
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            Console.WriteLine("the datatable " + datatable);
            UserProfile userProfile = prepareUserProfile(datatable, 0);
            //  else
            //  {
            //create  new UserProfile(senderId, channel, )
            //      userProfile = createUserProfile(senderId, channel, isPrivateMessage);
            //  }
            return userProfile;
        }

        private UserProfile prepareUserProfile(DataTable datatable, int i)
        {
            Console.WriteLine("The datatablee " + datatable);
            UserProfile userProfile = null;
            if (datatable.Rows.Count > 0)
            {
                // get the entire user profile object
                String userProfileId = datatable.Rows[i]["UserProfileId"].ToString();
                String senderName = datatable.Rows[i]["SenderName"].ToString();
                String fbWallId = datatable.Rows[i]["FBWallId"].ToString();
                String twitterId = datatable.Rows[i]["TwitterId"].ToString();
				String webId = datatable.Rows[i]["WebId"].ToString();
                String fbDirectID = datatable.Rows[i]["FBDirectId"].ToString();
                String customerId = datatable.Rows[i]["CustomerId"].ToString();
                String lastCathyConversationId = datatable.Rows[i]["LastCathyConversationId"].ToString();
                String lastUserAgentConversationId = datatable.Rows[i]["LastUserAgentConversationId"].ToString();
                bool isDuplicateProfile = (bool)(datatable.Rows[i]["isDuplicateProfile"]);
                DateTime createdDate = Convert.ToDateTime(datatable.Rows[i]["CreatedDate"]);
                DateTime updatedDate = Convert.ToDateTime(datatable.Rows[i]["UpdatedDate"]);
                userProfile = new UserProfile(userProfileId, senderName, twitterId,webId, fbWallId, fbDirectID, customerId, lastCathyConversationId, lastUserAgentConversationId, isDuplicateProfile, createdDate, updatedDate);

            }

            return userProfile;
        }

        private string prepareQueryString(string channel, bool isPrivateMessage)
        {
            // get userprofile from database for senderId
            string queryString = null;
            if (channel.Equals(CathyConstants.twitterChannel))
            {
                queryString = "SELECT * from CATHY_USERPROFILE where twitterId = @senderId and clientID = @clientID;";
            }
            else if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == false)
            {
                queryString = "SELECT * from CATHY_USERPROFILE where FBWallId = @senderId and clientID = @clientID;";
            }
            else if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == true)
            {
                queryString = "SELECT * from CATHY_USERPROFILE where FBDirectId = @senderId and clientID = @clientID;";
            }
			else if (channel.Equals(CathyConstants.webChannel))
            {
                queryString = "SELECT * from CATHY_USERPROFILE where webId = @senderId and clientID = @clientID;";
            }

            return queryString;
        }

        private string prepareUpdateString(string channel, bool isPrivateMessage, bool isCathyConversation)
        {
            // get userprofile from database for senderId
            string queryString = null;
            string colLastConversationID = null;
            if (isCathyConversation)
            {
                colLastConversationID = "LastCathyConversationId";
            }
            else
            {
                colLastConversationID = "LastUserAgentConversationId";
            }
            
            if (channel.Equals(CathyConstants.twitterChannel))
            {
                queryString = "update CATHY_USERPROFILE set "+colLastConversationID+" = @lastConversationId where twitterId = @senderId and clientId = @clientId;";
            }
            else if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == false)
            {
                queryString = "update CATHY_USERPROFILE set " + colLastConversationID + " = @lastConversationId where  FBWallId = @senderId and clientId = @clientId;";
            }
            else if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == true)
            {
                queryString = "update CATHY_USERPROFILE set " + colLastConversationID + " = @lastConversationId where  FBDirectId = @senderId and clientId = @clientId;";
            }
			if (channel.Equals(CathyConstants.webChannel))
            {
                queryString = "update CATHY_USERPROFILE set " + colLastConversationID + " = @lastConversationId where webId = @senderId and clientId = @clientId;";
            }

            return queryString;
        }

        //create new userProfile
        public UserProfile createUserProfile(string senderId, string senderName,  string channel, bool isPrivateMessage)
        {
            string queryString = "insert into CATHY_USERPROFILE (userprofileId, senderName, twitterId, FbWallId, FbDirectId, CreatedDate, IsDuplicateProfile, updatedDate, clientID, webId) values(@userprofileId, @senderName, @twitterId, @FbWallId, @FbDirectId, @createdDate, @IsDuplicateProfile, @updatedDate, @clientID, @webId);";
            String twitterId = "";
            String fbWallId = "";
            String fbDirectId = "";
			String webId = "";
            string userprofileId = Guid.NewGuid().ToString();
            DateTime updatedDate = DateTime.MinValue;

            if (channel.Equals(CathyConstants.twitterChannel))
            {
                twitterId = senderId;
            }
			else if(channel.Equals(CathyConstants.webChannel))
             {
                    webId = senderId;
              }
            else if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == true)
            {
                fbDirectId = senderId;
            }
            else if (channel.Equals(CathyConstants.facebookChannel) && isPrivateMessage == false)
            {
                fbWallId = senderId;
            }

            DateTime createdDate = DateTime.Now;
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@userprofileId", SqlDbType.VarChar) { Value = userprofileId},
                 new NpgsqlParameter("@senderName", SqlDbType.VarChar) { Value = senderName },
                 new NpgsqlParameter("@twitterId", SqlDbType.VarChar) { Value = twitterId },
				 new NpgsqlParameter("@webId", SqlDbType.VarChar) { Value = webId },               
                 new NpgsqlParameter("@FbWallId", SqlDbType.VarChar) { Value = fbWallId },
                 new NpgsqlParameter("@FbDirectId", SqlDbType.VarChar) { Value = fbDirectId },
                 new NpgsqlParameter("@createdDate",SqlDbType.DateTime) { Value = createdDate},
                  new NpgsqlParameter("@IsDuplicateProfile",SqlDbType.Bit) { Value = false},
                  new NpgsqlParameter("@updatedDate",SqlDbType.DateTime) { Value = createdDate},
                  new NpgsqlParameter("@clientID",SqlDbType.VarChar) { Value = CathyRequestOrchestrator.clientId}

            };

            Console.WriteLine("the query string is " + queryString);
            bool success = access.ExecuteNonQuery(queryString, CommandType.Text, sqlParams);
            Console.WriteLine("the success is " + success);

            UserProfile userProfile = new UserProfile(userprofileId, senderName, twitterId,webId,fbWallId, fbDirectId, null, null, null, false, createdDate, updatedDate);
            return userProfile;

        }

        //Update user profile for Customer
        void updateProfileForCustomer(UserProfile profile, string customerId)
        {

            string queryString = "update CATHY_USERPROFILE set customerId = @customerId where twitterId = @twitterId or fbwallId = @fbwallId or fbDirectId = @fbDirectId and clientId = @clientId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@customerId", SqlDbType.VarChar) { Value = customerId},
                 new NpgsqlParameter("@twitterId", SqlDbType.VarChar) { Value = profile.TwitterId },
                 new NpgsqlParameter("@fbwallId", SqlDbType.VarChar) { Value = profile.FbWallId },
                 new NpgsqlParameter("@fbDirectId", SqlDbType.VarChar) { Value = profile.FbDirectId},
                 new NpgsqlParameter("@clientId", SqlDbType.VarChar) { Value = CathyRequestOrchestrator.clientId}
            };
            bool success = access.ExecuteNonQuery(queryString, CommandType.Text, sqlParams);
            Console.WriteLine("the success is customer is updated " + success);

        }

        //Get all user profiles for a Customer
        public ArrayList getProfilesForCustomer(string customerId)
        {
            ArrayList profileList = new ArrayList();
            string queryString = "select * CATHY_USERPROFILE where customerId = @customerId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@customerId", SqlDbType.VarChar) { Value = customerId}
            };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            UserProfile userprofile = null;
            for (int i = 0; i < datatable.Rows.Count; i++)
            {
                userprofile = prepareUserProfile(datatable, i);
                profileList.Add(userprofile);


            }
            return profileList;
        }

        public void updateConversationDetailsForSender(string lastConversationId, String channel, bool isPrivateMessage, string senderId, bool isCathyConversation)
        {
            string queryString = prepareUpdateString(channel, isPrivateMessage, isCathyConversation);
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@lastConversationId", SqlDbType.VarChar) { Value = lastConversationId},
                 new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId },
                 new NpgsqlParameter("@clientId", SqlDbType.VarChar) { Value = CathyRequestOrchestrator.clientId},
            };
            bool success = access.ExecuteNonQuery(queryString, CommandType.Text, sqlParams);
            Console.WriteLine("the conversationId is updated " + success);

        }

        public bool isSenderAgent(string senderId)
        {
            string queryString = "select * from AGENT where agent_Id = @senderId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
            };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                return true;
            }
            return false;
        }

        public  string findAgentID(String channel)
        {
            string queryString = "select * from agent where agent_skill='Default' and channel = @channel";
            
            NpgsqlParameter[] sqlParams = {
              
                 new NpgsqlParameter("@channel", SqlDbType.VarChar) { Value = channel}
            };

            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                String agentID=datatable.Rows[0]["agent_id"].ToString();
                return agentID;
            }
            return null;


        }

        public  string findAgentConversationID(String channel)
        {
            string queryString = "select * from agent where agent_skill='Default' and channel = @channel";
           
            NpgsqlParameter[] sqlParams = {

                 new NpgsqlParameter("@channel", SqlDbType.VarChar) { Value = channel}
            };

            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                String agentID = datatable.Rows[0]["agent_conversationid"].ToString();
                return agentID;
            }

            return null;

        }



        public UserProfile getUserProfileForAgentConversation(string conversationId)
        {
            string queryString = "select * from Cathy_userProfile where lastUserAgentConversationId = @conversationId and clientId = @clientId";
            UserProfile profile = null;
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@conversationId", SqlDbType.VarChar) { Value = conversationId},
                 new NpgsqlParameter("@clientId", SqlDbType.VarChar) { Value = CathyRequestOrchestrator.clientId}
            };

            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                profile = prepareUserProfile(datatable, 0);
            }
           if(profile ==null)
            { 
                queryString = "select * from Cathy_userProfile where lastCathyConversationId = @conversationId1 and clientId = @clientId";
                NpgsqlParameter[] sqlParams1 = {
                new NpgsqlParameter("@conversationId1", SqlDbType.VarChar) { Value = conversationId},
                new NpgsqlParameter("@clientId", SqlDbType.VarChar) { Value = CathyRequestOrchestrator.clientId}
            };
                DataTable datatable1 = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams1);
                if (datatable1.Rows.Count > 0)
                {
                    profile = prepareUserProfile(datatable1, 0);
                }

            }

            return profile;
        }
    }
}