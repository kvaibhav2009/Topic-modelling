﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.EnterpriseServices;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;



namespace CathyRestAPI.Models
{
  
    public class CathyForBanking
    {
        CathyRequest request;
        public static string conversationStage = "1";
        public string Intent = String.Empty;
        public CathyForBankingResponse bankingresponse = null;
        static DataAccess access = new DataAccess();

        public string reply = string.Empty;

        public int dialogseq = 0;
        
        public CathyForBanking(CathyRequest request)
        {
            this.request = request;
            Task.Run(async () =>
            {
                bankingresponse= await getIntent(request.RequestMessage);
            }).Wait();
            
        }

        static async Task<CathyForBankingResponse> getIntent(string requestMessage)
        {
            using (var client1 = new HttpClient())
            {
                client1.BaseAddress = new Uri("https://api.projectoxford.ai");

                string id = "0430b2586cd44030bd176bced007fd60";//e32960c9-ebf6-4620-9312-94bc2e7b8aad
                string subscriptionKey = "0430b2586cd44030bd176bced007fd60";//131c04cfa92d48fcabc529deb75a44f6

                string requestUri = "";

                requestUri = "/luis/v2.0/apps/9d5c1190-4abf-4797-9d19-d3e3f2972bb1?subscription-key=" + subscriptionKey + "&q=" + requestMessage;

                HttpResponseMessage response = new HttpResponseMessage();
                response = await client1.GetAsync(requestUri);

                return JsonConvert.DeserializeObject<CathyForBankingResponse>(await response.Content.ReadAsStringAsync());
                //return response;
            }
            //return "Hello" ;
        }

        public void CathyForBankingSwitch()
        {
            //conversationStage = getConversationStage(request.SenderId);
            //SessionManager.setSession("conversationStage", "1");

            Intent = bankingresponse.topScoringIntent.intent;
            dialogseq = getdialogseq(request.SenderId);
            /*
            var builder = require('botbuilder');

            var connector = new builder.ConsoleConnector().listen();
            var bot = new builder.UniversalBot(connector);
            */


            IDialogContext context = null; 
            
            context.ConversationData.SetValue("customer Name",request.SenderName);


            switch (dialogseq)
            {
                case 0: StartConversation();                       
                        break;
                case 1: Introduction();
                        //SessionManager.setSession("conversationStage", "1");
                        //if((SessionManager.conversationStage) != "1")
                        //IncrementconversationStage();
                        break;
                case 2: InvestmentforRD();
                        break;
                case 3: InvestGivenAmount();
                        break;
                case 4: InvestmentPeriodAgreed();
                        break;
                case 5: InvestmentROIAgreed();
                        break;
                case 6: LinkedAccount();
                        break;
                case 7: InvestmentDayOfMonth();
                        break;
                case 8: ChooseOption();
                        break;
                case 9: RedemptionAccount();
                        break;
                case 11:OTPConfirmation();
                        break;
                case 10:ConfirmationclosingRemarks();
                        break;

//           default :

            }

        }

        private void OTPConfirmation()
        {
            
        }

        private void ConfirmationclosingRemarks()
        {
            if ((Intent.Equals("ConfirmAndClose")) || (Intent.Equals("Yes")))
            {
                cleandialogseq(request.SenderId);

            }
        }

        private void RedemptionAccount()
        {
            if (Intent == "SalariedAccount")
            {     // temp session value of "Salary account"
            }
            if (Intent == "SavingsAccount")
            {    // temp session value of "SavingsAccount"
            }

            reply = "Your product – Recurring Deposit Super Savings Account has been created.  You will now be transitioned to confirmation screen where you can see the details of your product which has been created.  Thank you for chatting with me.  Have a wonderful day.";
            incrementdialogseq(request.SenderId); //C=10;

        }

        private void InvestmentDayOfMonth()
        {
            string dayofMonth = string.Empty;
            if (Intent == "InvestmentDayOfMonth")
            {
                foreach (Entities2 entityreceived in bankingresponse.entities)
                {
                    if (entityreceived.type == "DayOfMonth")
                    {
                        dayofMonth = entityreceived.entity;
                        incrementdialogseq(request.SenderId);
                    }                    
                }
                reply = "Ok two more questions only to open the account – For redemption – there are 2 options.Choose either of them.Option 1 – On the Redemption date, the account would be closed and the amount(Principle + interest) would be transferred to your linked account.Option 2 - On the Redemption date, the account would be closed and the amount (Principle + interest) would be converted to Term Deposit with same investment period and the rate of interest prevailing on that redemption date.";
            }
            if (Intent == "Number")
            {
                foreach (Entities2 entityreceived in bankingresponse.entities)
                {
                    if (entityreceived.type == "numericvalue")
                    {
                        dayofMonth = entityreceived.entity;
                        incrementdialogseq(request.SenderId);
                    }
                }
            }
            String dom= Regex.Replace(dayofMonth, "[^0-9]+", string.Empty);
            dom = extractNumber(dom);
            
             //increment the value of C; C=8;

        }

        private string extractNumber(string str)
        {
            StringBuilder builder = new StringBuilder();
            char a;
            int x = 0;
           
            for (int i = 0; i < str.Length; i++)
            {
                if (Char.IsDigit(str[i]))
                {
                    //builder.Append(x).Append(str[i]);
                    a = (char)str[i];
                    builder.Append(a);
                    
                }
                   
            }
            str = builder.ToString();

            return str;
        }

        private int getdialogseq(String senderId)
        {
            string queryString = "select * from conversationstage where SenderId = @senderId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
            };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            int c = 0;
            if (datatable.Rows.Count > 0)
            {
                c = (int)(datatable.Rows[0]["stage"]);

            }
            return c;

        }

        private void InvestmentROIAgreed()
        {
            string ROI = string.Empty;
            if (Intent == "InvestmentROIAgreed" || Intent=="Yes")
            {
                reply = "Right then, "+request.SenderName+", You have a salary account and a savings account, from which account do you want us to transfer money to your Recurring Deposit Super Savings Account every month?";
                //increment the value of C; C=6;
                incrementdialogseq(request.SenderId);
            }
        }

        private void InvestmentPeriodAgreed()
        {
            string duration = string.Empty;
            if(Intent == "InvestmentPeriodAgreed")
            {
                //copy the entity duration
                foreach (Entities2 entityreceived in bankingresponse.entities)
                {
                    if (entityreceived.type == "Duration")
                    {
                        duration = entityreceived.entity;
                        incrementdialogseq(request.SenderId);
                        break;
                    }
                }
                Regex.Replace(duration, "[^0-9]+", string.Empty);
                duration=extractNumber(duration); ;
                reply = "Ok, for "+duration+" months you will earn 4% rate of interest, we have a special rate of 5% rate of interest for investments up to or beyond 36 months, do you want to consider them? ";
                //increment the value of c//C=5
            }

        }

        private void InvestGivenAmount()
        {
            String Amount = string.Empty;
            if(Intent == "InvestGivenAmount")
            {  //Copy the entity investment amount and ROI agreed
                foreach (Entities2 entityreceived in bankingresponse.entities)
                {
                    if (entityreceived.type == "Amount")
                    {
                        Amount = entityreceived.entity;
                        
                        break;
                    }
                   
                }
                Regex.Replace(Amount, "[^0-9]+", string.Empty);
                String amt=Amount;
                amt = extractNumber(Amount);
                reply = "Right then, How many months do you want to invest the specified amount "+amt+" for? ";
                incrementdialogseq(request.SenderId);
                return;
            }
            if(Intent == "InvestmentNotWorthy")
            {
                reply="Canceling your request";
                return;
            }

        }
        public void StartConversation()
        {
           reply= "Hello "+request.SenderName+".I'm AI Cognitive Assistant Cathy. Congratulations on successfully getting your Agreement in Principle!You're a big step closer to being able to buy your product – Recurring Deposit Super Savings Account.Now we need to talk the options that you can explore.I will ask you a few questions, and your answers will enable me to create the product for you.Are you ready to get started ?";
            //Adddialogseq C=1
           startdialogseq(request.SenderId);
        }

        private void startdialogseq(string senderId)
        {
            int i = 1;
            string commandString = "insert into conversationstage values (@senderId , @conversationdialogstage) ";
            NpgsqlParameter[] sqlParams1 = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                 new NpgsqlParameter("@conversationdialogstage", SqlDbType.Int) { Value = i}
                };
            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams1);

        }

        private void incrementdialogseq(string senderId)
        {
            int i = dialogseq;
            i++;
            String commandString = "update conversationstage set stage = @conversationdialogstage where senderId = @senderId";
            NpgsqlParameter[] sqlParams1 = {
                     new NpgsqlParameter("@conversationdialogstage", SqlDbType.Int) { Value = i},
                     new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
                };
            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams1);
            if (success)
            {
                dialogseq = i;
            }

        }

        private void cleandialogseq(string senderId)
        {
            int i = dialogseq;
            i++;
            String commandString = "delete from conversationstage";
            NpgsqlParameter[] sqlParams1 = {
                     new NpgsqlParameter("@conversationdialogstage", SqlDbType.Int) { Value = i},
                     new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
                };
            bool success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams1);
            if (success)
            {
                dialogseq = i;
            }

        }

        public void IncrementconversationStage()
        {
            string conversationStage=SessionManager.getSession("conversationStage");
            char c = conversationStage[0];
            int i = (int)c;
             conversationStage=""+i++;
            SessionManager.setSession("conversationStage", conversationStage);
        }

        public int getConversationStage(string senderId)
        {
            
            int stage = 0;
            string queryString = "select * from conversationstage where senderId = @senderId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
            };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);

            if (datatable.Rows.Count > 0)
            {
                stage =(int)(datatable.Rows[0]["senderId"]);

            }

            return stage;
        }

        private void ConfirmationClosingRemarks()
        {
            throw new NotImplementedException();
        }
        private void ChooseOption()
        {
            if ((Intent.Equals("Option1Chosen")) || (Intent.Equals("Option2Chosen")))
            {
                // send the option
                reply = "Ok, last question – Do you want the redemption amount transferred to your linked account";
                incrementdialogseq(request.SenderId); //C=9;
            }
        }

        
       
        private void LinkedAccount()
        {
            if (Intent.Equals("SalariedAccount") || Intent.Equals("Yes"))
            {              // temp session value of "Salary account"
            }
            if (Intent == "SavingsAccount")
            {    // temp session value of "SavingsAccount"
            }
            reply = "Right then, on which date of every month do you want to have the amount transferred to your investment account?";
            incrementdialogseq(request.SenderId); //C=7;

        }

        private void InvestmentPeriod()
        {
            throw new NotImplementedException();
        }

        private void InvestmentforRD()
        {

            if ((Intent.Equals("InvestmentforRD")) || (Intent.Equals("Yes")))
            {
                reply = "Would you like to invest $200 every month which is based on 25 % of your average balance of amount available in your salary account(main account) at the end of every month?";
                incrementdialogseq(request.SenderId);//increment the value of C;//C=3;

            }
        }

        private void Introduction()
        {
            switch (Intent)
            {
                case "CreateRecurringDeposit":
                                                reply = "Ok,"+request.SenderName+", let's get started. Recurring Deposit Super Savings Account would require you to invest a defined amount every month.";
                                                //increment the value of C //C=2
                                                incrementdialogseq(request.SenderId);
                                                break;
                case "SkipRDcreation":
                    break;
                case "Yes":         reply = "Ok," + request.SenderName + ", let's get started. Recurring Deposit Super Savings Account would require you to invest a defined amount every month.";
                                    incrementdialogseq(request.SenderId);//increment the value of C //C=2
                                    break;
                case "Negative":
                    break;
            }

        }



    }
}