﻿using Npgsql;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class NegativeSentimentDBManager
    {
        static DataAccess access = new DataAccess();

        public static bool setSentimentForUser(string senderId, bool sentiment)
        {
            string queryString = "select * from CATHY_NEGATIVECONVERSATION_STATUS where SenderId = @senderId";
            bool success = false;
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
            };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
            string commandString = null;

            if (datatable.Rows.Count <= 0)
            {
                commandString = "insert into CATHY_NEGATIVECONVERSATION_STATUS values (@senderId , @sentiment) ";
                NpgsqlParameter[] sqlParams1 = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                 new NpgsqlParameter("@sentiment", SqlDbType.Bit) { Value = sentiment}
                };
                success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams1);

            }
            else
            {
                commandString = "update CATHY_NEGATIVECONVERSATION_STATUS set IsSentimentNegative = @sentiment where senderId = @senderId";
                NpgsqlParameter[] sqlParams1 = {
                     new NpgsqlParameter("@sentiment", SqlDbType.Bit) { Value = sentiment},
                     new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
                };
                success = access.ExecuteNonQuery(commandString, CommandType.Text, sqlParams1);
            }
            return success;
        }

        public static bool getNegativeSentimentForUser(string senderId)
        {
            bool isSentimentNegative = false;
            string queryString = "select * from CATHY_NEGATIVECONVERSATION_STATUS where SenderId = @senderId";
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId}
            };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);

            if (datatable.Rows.Count > 0)
            {
                isSentimentNegative = (bool)(datatable.Rows[0]["isSentimentNegative"]);

            }
            return isSentimentNegative;
        }

    }

}