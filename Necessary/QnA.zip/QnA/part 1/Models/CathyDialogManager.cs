﻿using Npgsql;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class CathyDialogManager
    {
        public ArrayList getAllProductNames(String productname)
        {

            ArrayList productNameList = new ArrayList();


            if (productname.Contains("car") || productname.Contains("auto") || productname.Contains("motor") || productname.Contains("vehicle") || productname.Contains("Auto"))
            {
                productname = "Auto";
            }

            else if (productname.Contains("home") || productname.Contains("house") || productname.Contains("Home"))
            {
                productname = "Home";
            }
            else
            {
                productname = "Auto";
            }

            string queryproductString = "SELECT * from PRODUCTINFO Where Product_LOB = @Product_LOB and Product_Description != @Product_Description" ;
            try
            {
                DataAccess access = new DataAccess();

                NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@Product_LOB", SqlDbType.VarChar) { Value = productname},
                new NpgsqlParameter("@Product_Description", SqlDbType.VarChar) { Value = "Tryg"}
                };

                DataTable datatable = access.ExecuteParamerizedSelectCommand(queryproductString, CommandType.Text, sqlParams);

                if (datatable.Rows.Count > 0)
                {
                    productNameList.Add(datatable.Rows[0]["Product_Name"].ToString());
                    productNameList.Add(datatable.Rows[1]["Product_Name"].ToString());

                }
                else
                {
                    productNameList.Add("Sorry no products found");
                   
                }
                
            }
            catch (Exception e)
            {
                productNameList.Add(e.Message);

            }

            return productNameList;

        }

        public ArrayList getProductName(String productname)
        {
            ArrayList productNameList = new ArrayList();

            if (productname.Contains("car") || productname.Contains("auto") || productname.Contains("motor") || productname.Contains("vehicle") || productname.Contains("Auto"))
            {
                productname = "Auto";
            }

            else if (productname.Contains("home") || productname.Contains("house"))
            {
                productname = "Home";
            }
            else
            {
                productname = "Auto";
            }

            string queryproductString = "Select * from PRODUCTINFO where Product_LOB = @Product_LOB;";


            try
            {
                DataAccess access = new DataAccess();

                NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@Product_LOB", SqlDbType.VarChar) { Value = productname},
                new NpgsqlParameter("@Product_Description", SqlDbType.VarChar) { Value = "Tryg"}
                };

                DataTable datatable = access.ExecuteParamerizedSelectCommand(queryproductString, CommandType.Text, sqlParams);

                if (datatable.Rows.Count > 0)
                {
                    productNameList.Add(datatable.Rows[0]["Product_Name"].ToString());
                   
                }
                else
                {
                    productNameList.Add("Sorry no products found");

                }

            }
            catch (Exception e)
            {
                productNameList.Add(e.Message);

            }
            
            return productNameList;
        }

        public ArrayList validatepolicydetails(String FirstName, String PolicyNumber, String ZipCode)
        {
            ArrayList policydetails = new ArrayList();
            string queryString = "Select * from CUSTOMER a, POLICY b Where a.Customer_ID=b.Customer_ID and b.Policy_No = @policyNumber and a.Customer_First_Name = @firstName and a.Zip = @zip and EDS_End_Date is null;";
            try
            {
                DataAccess access = new DataAccess();

                NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@policyNumber", SqlDbType.VarChar) { Value = PolicyNumber},
                new NpgsqlParameter("@firstName", SqlDbType.VarChar) { Value = FirstName},
                new NpgsqlParameter("@zip", SqlDbType.VarChar) { Value = ZipCode}
                };
                DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);

                if (datatable.Rows.Count > 0)
                {
                    policydetails.Add(datatable.Rows[0]["Installment_Amount"].ToString());
                    policydetails.Add(datatable.Rows[0]["Next_Instalment_Due_Date"].ToString());

                }
                else
                {
                    policydetails.Add("Sorry no products found");

                }
                
            }
            catch (Exception e)
            {
                    policydetails.Add(e.Message);
            }


            return  policydetails;
        }

        public ArrayList getclaimstatus(String ClaimNumber, String FirstName, String ZipCode)
        {

            //Select * from CUSTOMER a, CLAIMS b Where a.Customer_ID = b.Customer_ID  and b.Claim_no = 'CLM0000001' and a.Customer_First_Name = 'Shiladitya' and a.Zip = '07302'

            //Select * from CUSTOMER a, CLAIMS b Where a.Customer_ID = b.Customer_ID  and b.Claim_no = 'CLM0000001' and a.Customer_First_Name = 'Shiladitya'  and a.Customer_Last_Name = 'Sengupta'  and a.Zip = '07302'


            ArrayList claimdetails = new ArrayList();

            string queryString = "Select * from CUSTOMER a, CLAIMS b Where a.Customer_ID=b.Customer_ID and b.Claim_no = @Claim_no and a.Customer_First_Name = @Customer_First_Name and a.Zip = @Zip;";

            NpgsqlParameter[] sqlParams = {
                new  NpgsqlParameter("@Claim_no", SqlDbType.VarChar) { Value = ClaimNumber},
                new NpgsqlParameter("@Customer_First_Name", SqlDbType.VarChar) { Value = FirstName},
                new NpgsqlParameter("@Zip", SqlDbType.VarChar) { Value = ZipCode}
            };

            try
            {
                DataAccess access = new DataAccess();

                DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
                if (datatable.Rows.Count > 0)
                {
                    claimdetails.Add(datatable.Rows[0]["Policy_No"].ToString());
                    claimdetails.Add(datatable.Rows[0]["Claim_Status"].ToString());

                }
            }
            catch (Exception e)
            {
                claimdetails.Add(e.Message);
            }

            return claimdetails;

        }


        public ArrayList cancelpolicydetails(String FirstName, String PolicyNumber, String ZipCode)
        {

            ArrayList policydetails = new ArrayList();
            
            string queryString = "Select * from CUSTOMER a, POLICY b Where a.Customer_ID=b.Customer_ID and b.Policy_No = @policyNumber and a.Customer_First_Name = @firstName and a.Zip = @zip and EDS_End_Date is null;";

                NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@policyNumber", SqlDbType.VarChar) { Value = PolicyNumber},
                new NpgsqlParameter("@firstName", SqlDbType.VarChar) { Value = FirstName},
                new NpgsqlParameter("@zip", SqlDbType.VarChar) { Value = ZipCode}
            };


            try
            {
                DataAccess access = new DataAccess();
                DataTable datatable = access.ExecuteParamerizedSelectCommand(queryString, CommandType.Text, sqlParams);
                if (datatable.Rows.Count > 0)
                {
                    policydetails.Add(datatable.Rows[0]["Effective_Date"].ToString());
                    policydetails.Add(datatable.Rows[0]["Expiry_Date"].ToString());
                    policydetails.Add(datatable.Rows[0]["Phone_number"].ToString());

                }
            }
            catch (Exception e)
            {
                policydetails.Add(e.Message);
            }
           
            return policydetails;
        }
        
    }

}