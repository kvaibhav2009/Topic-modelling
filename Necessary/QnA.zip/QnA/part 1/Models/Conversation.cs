﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class Conversation
    {
        public string ConversationId { get; set; }
        public string Channel { get; set; }
        public string SenderId { get; set; }
        public string ParentPostId { get; set; }
        public string ConversationStatus { get; set; }

        public string ConversationSkillType { get; set; }
        public string ConversationMode { get; set; }

        public string ConversationAgentId { get; set; }

        public bool IsCathyConversation { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime UpdatedDate { get; set; }


        public Conversation(string conversationId, string channel, string senderId, string parentpostId, string conversationStatus, string conversationSkillType, DateTime createdDate, DateTime updatedDate, bool isCathyConversation)
        {
            this.ConversationId = conversationId;
            this.Channel = channel;
            this.SenderId = senderId;
            this.ParentPostId = parentpostId;
            this.ConversationStatus = conversationStatus;
            this.ConversationSkillType = conversationSkillType;
            this.IsCathyConversation = isCathyConversation;
            this.CreatedDate = createdDate;
            this.UpdatedDate = updatedDate;
        }

        public Conversation(string conversationId, string channel, string senderId, string parentpostId, string conversationStatus, string conversationSkillType, string conversationMode, string conversationAgentId, DateTime createdDate, DateTime updatedDate, bool isCathyConversation)
        {
            this.ConversationId = conversationId;
            this.Channel = channel;
            this.SenderId = senderId;
            this.ParentPostId = parentpostId;
            this.ConversationStatus = conversationStatus;
            this.ConversationSkillType = conversationSkillType;
            this.ConversationMode = conversationMode;
            this.ConversationAgentId = conversationAgentId;
            this.IsCathyConversation = isCathyConversation;
            this.CreatedDate = createdDate;
            this.UpdatedDate = updatedDate;
        }
    }
}