﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class CathyBuffer
    {
        static DataAccess access = new DataAccess();

        public static bool InsertZipcode(string senderId,string zipcode)
        {
            string queryString = "insert into CATHY_NEGATIVECONVERSATION_BUFFER values (@senderId,null,null,null,@zipcode )";
            bool success = false;
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                new NpgsqlParameter("@zipcode", SqlDbType.VarChar) { Value = zipcode}
            };
            success = access.ExecuteNonQuery(queryString, CommandType.Text, sqlParams);
            

            return success;
        }

        public static bool UpdateNameDOB(string senderId, string name,string dob)
        {
            string queryString = "update CATHY_NEGATIVECONVERSATION_BUFFER set fname=@name,dob=@dob where senderId=@senderId";
            bool success = false;
            
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                new NpgsqlParameter("@name", SqlDbType.VarChar) { Value = name},
                new NpgsqlParameter("@dob", SqlDbType.VarChar) { Value = dob}
            };

            success = access.ExecuteNonQuery(queryString, CommandType.Text, sqlParams);

            return success;
        }

        public static bool Updatephonenumber(string senderId, string phonenumber)
        {
            string queryString = "update CATHY_NEGATIVECONVERSATION_BUFFER set phoneno=@phonenumber where senderId=@senderId";
            bool success = false;
            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId", SqlDbType.VarChar) { Value = senderId},
                new NpgsqlParameter("@phonenumber", SqlDbType.VarChar) { Value = phonenumber}               
            };

            success = access.ExecuteNonQuery(queryString, CommandType.Text, sqlParams);

            return success;
        }

        public static string validateRetrieveUserDetails(string senderId,string getvalue)
        {
            string emailID = string.Empty;
            //string queryString = "select p.policy_no,c.email from policy p join customer c on p.customer_id=c.customer_id where c.customer_first_name='Shiladitya' and c.date_of_birth='1985-02-01' and c.phone_number='8932783999' and p.eds_end_date is not null";
            string sqlQuery = "select p.policy_no,c.email from policy p join customer c on p.customer_id=c.customer_id and eds_date is not null and lower(c.customer_first_name) in (select b.fname from CATHY_NEGATIVECONVERSATION_BUFFER b,customer d where b.fname =lower(d.customer_first_name) and trim(b.dob)=trim(cast(d.date_of_birth as varchar)) and b.phoneno=d.phone_number and b.senderId = @senderId)";

            string policy_no = string.Empty;
            string email = string.Empty;
            string phoneno = string.Empty;
            string requiredvalue = string.Empty;

            bool success = false;

            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId",SqlDbType.VarChar) { Value = senderId},
            };

            DataTable datatable = access.ExecuteParamerizedSelectCommand(sqlQuery, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                policy_no = datatable.Rows[0]["policy_no"].ToString();
                email = datatable.Rows[0]["email"].ToString();

                success = true;
            }
            else
            {
                return "No values";
            }

            if (success)
            {
                if (getvalue == "email")
                    requiredvalue = email;
                else
                    requiredvalue = policy_no;
            }
            
            return requiredvalue;
        }


        ///

        public static string validateRetrieveCustomername(string senderId, string getvalue)
        {
            string emailID = string.Empty;
            //string queryString = "select p.policy_no,c.email from policy p join customer c on p.customer_id=c.customer_id where c.customer_first_name='Shiladitya' and c.date_of_birth='1985-02-01' and c.phone_number='8932783999' and p.eds_end_date is not null";
            string sqlQuery = "select p.policy_no,c.email,c.customer_first_name from policy p join customer c on p.customer_id=c.customer_id and eds_date is not null and lower(c.customer_first_name) in (select b.fname from CATHY_NEGATIVECONVERSATION_BUFFER b,customer d where b.fname =lower(d.customer_first_name) and trim(b.dob)=trim(cast(d.date_of_birth as varchar)) and b.phoneno=d.phone_number and b.senderId = @senderId)";

            string policy_no = string.Empty;
            string email = string.Empty;
            string phoneno = string.Empty;
            string requiredvalue = string.Empty;
            string customername = string.Empty;
            bool success = false;

            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId",SqlDbType.VarChar) { Value = senderId},
            };

            DataTable datatable = access.ExecuteParamerizedSelectCommand(sqlQuery, CommandType.Text, sqlParams);
            if (datatable.Rows.Count > 0)
            {
                policy_no = datatable.Rows[0]["policy_no"].ToString();
                email = datatable.Rows[0]["email"].ToString();
                customername= datatable.Rows[0]["customer_first_name"].ToString();
                success = true;
            }
            else
            {
                return "No values";
            }

            if (success)
            {
                requiredvalue = customername;
            }

            return requiredvalue;
        }






        public static bool clearsenderId(string senderId)
        {
            bool success = false;
            String query = "delete from CATHY_NEGATIVECONVERSATION_BUFFER where senderId = @senderId";

            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId",SqlDbType.VarChar) { Value = senderId},
            };

            success = access.ExecuteNonQuery(query, CommandType.Text, sqlParams);

            return success;

        } 



    }


}