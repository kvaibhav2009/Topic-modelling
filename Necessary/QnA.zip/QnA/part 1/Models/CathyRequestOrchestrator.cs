﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector.DirectLine.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Npgsql;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Tracing;
//using Accenture.AI.PLM.Web.App; 

namespace CathyRestAPI.Models
{
    
    public class CathyRequestOrchestrator :ApiController
    {
        // public static string secret_key = "NvV3KfKPl2Y.cwA.0WU.JUALc2eV1-PEJvlG9JN1KwEEvzNSIRu3zu6FlaeGJzk"; previous
        // public static string secret_key = "gdsBNtjo_II.cwA.vrQ.NCnaTno6y7FIfmMNvJBrsYhbm0g0Hk5td0IPx-ailo0";

        //public static string secret_key = "hbjOo9-6hyY.cwA.QKc.hlz_T6yKA-977WI0PR_rnROlhQ7U637DjvDlNf9T3Dw";
        //public static string Service_URL = "https://directline.botframework.com/api/conversations/";

        public static string secret_key = null;
        public static string Service_URL = null;
        public static string clientId = null;

        public string strReplyMesage = string.Empty;
        bool flag = false;
        
        UserProfileManager userprofileManager = new UserProfileManager();
        ConversationManager conversationManager = new ConversationManager();
        ClientManager clientManager = new ClientManager();

        long timestampvalue = 123456789;
        CathyResponse response1 = null;

        private static TraceSource _source = new TraceSource("Logs");

        public CathyResponse processMessage(CathyRequest request)
        {
            string answer = string.Empty;

            if (true)
            {
                CathyResponse QAresponse = null;

                Task.Run(async () =>
                {
                    answer = await CallLuis(request.RequestMessage);
                }).Wait();


                QAresponse = new CathyResponse();
                QAresponse.SenderId = request.SenderId;
                QAresponse.Channel = request.Channel;
                QAresponse.IsPrivateMessage = request.IsPrivateMessage;
                QAresponse.PostId = request.PostId;
                QAresponse.ResponseMessage = answer;



                return QAresponse;
            }


            //_source.TraceEvent(TraceEventType.Information, 0,  DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t ************  processMessage start ************ ");
            clientId = clientManager.getClient();
            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t ************  After clientID ************ ");
            Dictionary<string,string> botDetails = (Dictionary<string, string>)clientManager.loadBotDetails(clientId);
            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t ************  After checking BOT details ************ ");
            Service_URL = botDetails[CathyConstants.botURL].ToString();
            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t ************  Service URL ************ ");
            secret_key = botDetails[CathyConstants.botParam1].ToString();
            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t ************   secret_key ************ ");
            if (string.IsNullOrEmpty(request.RequestMessage))
                 request.RequestMessage = "dvsdvsdvsdvdvhbfgngf";

            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t ************   Request is empty ************ ");


            CathyResponse response = null;
            clientId = "C004";
            if (clientId == "C004")
            {
                CathyBanking banking = new CathyBanking(request);

                response1 = new CathyResponse();
                //if(IDialogContext context)
                if (request.RequestMessage == "#close#")
                {
                    banking.cleanentity();
                    banking.cleandialogseq(request.SenderId);
                    response1.ResponseMessage = "End of conversation";
                }
                else
                {
                banking.CathyForBankingSwitch();
                response1.ResponseMessage = CathyBanking.reply;
                }
                //CathyForBankingReturnResponse(request,banking);

               
                response1.SenderId = request.SenderId;
                response1.Channel = request.Channel;
                response1.IsPrivateMessage = request.IsPrivateMessage;
                response1.PostId = request.PostId;
                

                return response1;

                CathyForBanking cathybanking = new CathyForBanking(request);
                cathybanking.CathyForBankingSwitch();
                CathyForBankingReturnResponse(request,cathybanking);
                return response1;
            }



            //check
            if (userprofileManager.isSenderAgent(request.SenderId))
            {
                // if the sender is an agent, then populate the response based on the conversation Id obtained from message and
                // send the response to User    
                response = processAgentMessageForUser(request);
                _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t ************  After isSenderAgent ************ ");


            }
            else
            {
                _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t ************ processMessage start ************ ");


                _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t Fetching User Profile");
                
                UserProfile userprofile = getUserProfile(request);

               _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t Setting User Profile");


                // request.SentimentValue = "Negative";


                if (request.SentimentValue.Equals(CathyConstants.negativeSentiment))
                {
                    response = processNegativeMessageForAgent(request, userprofile);
                }

                else if (request.SentimentValue.Equals(CathyConstants.negativeSentimentforVA) || NegativeSentimentDBManager.getNegativeSentimentForUser(request.SenderId))
                {

                    //response = processNegativeMessageForAgent(request, userprofile);
                    NegativeSentimentDBManager requestSentiment = new NegativeSentimentDBManager();
                    bool t= NegativeSentimentDBManager.setSentimentForUser(request.SenderId,true);

                    CathyNewModel model = new CathyNewModel(request);

                    model.ConversationFlow();
                    int i = 0;
                    while(!model.pass)
                    {
                        i++;
                    }
                    
                    String responseforNegativeSentiment = model.response;
                    

                    returnResponse(model,request, responseforNegativeSentiment);
                    
                    return response1;
                    
                }
                else
                {
                    if (request.IsPrivateMessage == false && request.RequestMessage.StartsWith("Token"))
                    {
                        response = processInvalidTokenMessageForUser(request, userprofile, "Token messages should be sent in private chat only");
                    }
                    else if (request.IsPrivateMessage == true && request.RequestMessage.StartsWith("Token"))
                    {
                        response = processTokenMessage(request, userprofile);
                    }
                    else
                    {
                       if (request.IsPrivateMessage == false && request.Channel.Equals("Facebook"))
                        {
                            //String str = request.requestMessageTimestamp;
                            //timestampvalue = Convert.ToInt64(str);
                            timestampvalue = request.requestMessageTimestamp;
                            //if (requestIsPresent(request, timestampvalue))
                            
                            if(false)
                            {
                                response = new CathyResponse();  //1476520504
                                response.SenderId = request.SenderId;
                                response.Channel = request.Channel;
                                response.IsPrivateMessage = request.IsPrivateMessage;
                                response.PostId = request.PostId;
                                response.Action = "SendToNone";
                                response.AgentId = null;
                                response.ResponseMessage = " ";
                        
                                return response;
                            }
                                                             
                        }
                        

                        _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + " \t BOT request = " +request.RequestMessage);
                        var task = PostMessage(request.RequestMessage, userprofile, request).GetAwaiter().GetResult();
                        _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + " \t BOT Response = " + strReplyMesage);
                        response = new CathyResponse();
                        response.SenderId = request.SenderId;
                        response.Channel = request.Channel;
                        response.IsPrivateMessage = request.IsPrivateMessage;
                        response.PostId = request.PostId;
                        if (flag)
                        {
                            response.Action = CathyConstants.sendToBoth;
                            response.AgentId = userprofileManager.findAgentID(request.Channel);
                            flag = false;
                        }
                        else
                        {
                            response.Action = CathyConstants.sendToUser;
                            response.AgentId = null;
                        }
                        
                        response.ResponseMessage = strReplyMesage;
                        

                        //if message from Bot is null then send to User Agent to handle
                        if (String.IsNullOrEmpty(strReplyMesage))
                        {
                            response = processMessageForNonRepliedPost(userprofile, request);
                        }
                    }

                }
            }
            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t processMessage end ");
            return response;
        }

        private async Task<string> CallLuis(string query)
        {

            string resultnew = string.Empty;
            string answer = string.Empty;

            using (var client = new HttpClient())
            {
                var scoreRequest = new
                {

                    Inputs = new Dictionary<string, CathyQA>() {
                        {
                            "input1",
                            new CathyQA()
                            {
                                ColumnNames = new string[] {"Query"},
                                Values = new string[,] {  { ""+ query }  }
                            }
                        },
                    },
                    GlobalParameters = new Dictionary<string, string>()
                    {
                    }
                };

                Console.WriteLine("The query is" + scoreRequest);

                const string apiKey = "tAnObNC9xA7vYDwpDbfZFQXWMkGqwFYx2I2/kDTiPNnYOod3Jzq6Y3e7eI3HTYwgARD9D3TMyj4l75FWxETQYA=="; // Replace this with the API key for the web service
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/51fa06ca22e6469f8b55f689f2fdc19c/services/a523fab837a84d25baba354d12a79e68/execute?api-version=2.0&details=true");



                HttpResponseMessage response = await client.PostAsJsonAsync("", scoreRequest);

                if (response.IsSuccessStatusCode)
                {
                    resultnew = await response.Content.ReadAsStringAsync();


                    JObject joResponse = JObject.Parse(resultnew);
                    JObject ojObject = (JObject)joResponse["Results"];
                    JObject jsonoutput = (JObject)ojObject["output1"];
                    JObject jsonvalue = (JObject)jsonoutput["value"];
                    JArray arrvalues = (JArray)jsonvalue["Values"];
                    JArray arrval = (JArray)arrvalues[0];
                    answer = arrval[1].ToString();
                }
                else
                {
                    Console.WriteLine(string.Format("The request failed with status code: {0}", response.StatusCode));

                    // Print the headers - they include the requert ID and the timestamp, which are useful for debugging the failure
                    Console.WriteLine(response.Headers.ToString());

                    string responseContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(responseContent);
                }

                if (answer == "We are a paperless organization. All documents and billing will be through email only.")
                {
                    answer = "You know, we are going green. All policy documents will be emailed to you";
                }

                return answer;


            }
        }

        private void CathyForBankingReturnResponse(CathyRequest request, CathyForBanking cathyforbanking)
        {
            response1 = new CathyResponse();
            response1.SenderId = request.SenderId;
            response1.Channel = request.Channel;
            response1.IsPrivateMessage = request.IsPrivateMessage;
            response1.PostId = request.PostId;
            response1.ResponseMessage = cathyforbanking.reply;

        }

        public void returnResponse(CathyNewModel model,CathyRequest request,String reply)
        {
            
            response1 = new CathyResponse();
            response1.SenderId = request.SenderId;
            response1.Channel = request.Channel;
            response1.IsPrivateMessage = request.IsPrivateMessage;
            response1.PostId = request.PostId;
           if (reply.Contains("Affirmative"))
            {
               flag = true;
               reply = model.customername + "," + model.getpolicy + ", Request to post policy documents and email copy immediately";

            }
            if (flag)
            {
                response1.Action = CathyConstants.sendToBoth;
                response1.AgentId = userprofileManager.findAgentID(request.Channel);
                flag = false;
            }
            else
            {
                response1.Action = CathyConstants.sendToUser;
                response1.AgentId = null;
            }
            
            response1.ResponseMessage = reply;
            
        }

        public bool requestIsPresent(CathyRequest request, long timestampvalue)
        {
            String senderid = request.SenderId;
            String sendername = request.SenderName;
            DataAccess access = new DataAccess();
            String query = "select * from BufferConversation where senderID=@senderid and timestampvalue=@timestampvalue" ;

            NpgsqlParameter[] sqlParams = {
                new NpgsqlParameter("@senderId",SqlDbType.VarChar) { Value = senderid},
                  new NpgsqlParameter("@timestampvalue",SqlDbType.BigInt) { Value = timestampvalue}
             };
            DataTable datatable = access.ExecuteParamerizedSelectCommand(query, CommandType.Text, sqlParams);

            if (datatable.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                query = "insert into BufferConversation values(@senderid,@sendername,@timestampvalue)" ;
                NpgsqlParameter[] sqlParams1 = {
                new NpgsqlParameter("@senderId",SqlDbType.VarChar) { Value = senderid},
                new NpgsqlParameter("@sendername",SqlDbType.VarChar) { Value = sendername},
                new NpgsqlParameter("@timestampvalue",SqlDbType.BigInt) { Value = timestampvalue}
                
                    };

                bool success = access.ExecuteNonQuery(query, CommandType.Text, sqlParams1);
                return false;

            }


        }


        private async Task<bool> PostMessage(string message, UserProfile userprofile, CathyRequest request)
        {
            bool IsReplyReceived = false;
            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t Invoking LUIS BOT");
            HttpClient client = setupHttpClient();
            HttpResponseMessage response = await client.GetAsync("/api/tokens/").ConfigureAwait(false);
            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t Response received from LUIS Bot");
            String responsemessage = null;
            String LUISreply = null;
            
            if (response.IsSuccessStatusCode)
            {
                var conversation = new CathyConversation();
                CathyConversation ConversationInfo = new CathyConversation();
                // response = await client.PostAsJsonAsync("/api/conversations", conversation);
                string conversationUrl = null;
                _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t postmessage \t testing whether conversation is new or already present in history ");
                bool isconversationpresent = conversationManager.isConversationPresent(userprofile.LastCathyConversationId);
                _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t postmessage \t Executing DB query");

                if ((!String.IsNullOrEmpty(userprofile.LastCathyConversationId)) && isconversationpresent)
                {
                    _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t postmessage \t Conversation present");
                    response = await client.PostAsJsonAsync("/api/conversations/" + userprofile.LastCathyConversationId + "/messages", conversation);

                    ConversationInfo.conversationID = userprofile.LastCathyConversationId;

                    conversationUrl = userprofile.LastCathyConversationId + "/messages/";
                }
                else
                {

                    response = await client.PostAsJsonAsync("/api/conversations", conversation);
                    ConversationInfo = response.Content.ReadAsAsync(typeof(CathyConversation)).Result as CathyConversation;
                    conversationUrl = ConversationInfo.conversationID + "/messages/";

                }
                _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t ConvId" + ConversationInfo.conversationID);
                if (response.IsSuccessStatusCode)
                {

                    Conversation conversationObj = conversationManager.getCathyConversation(ConversationInfo.conversationID);
                    if (conversationObj == null)
                    {
                        conversationObj = conversationManager.createConversation(userprofile, ConversationInfo.conversationID, request.Channel, request.PostId, request.ParentPostId, request.IsPrivateMessage, request.SentimentValue, request.RequestMessage, true);
                    }
                    _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t Updating the conversation Details for User");

                    userprofileManager.updateConversationDetailsForSender(ConversationInfo.conversationID, request.Channel, request.IsPrivateMessage, request.SenderId, true);
                    _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t Conversation Details Updated");

                    userprofile.LastCathyConversationId = ConversationInfo.conversationID;
                    ConversationRequest conversationRequest = conversationManager.createConversationRequest(ConversationInfo.conversationID, request.PostId, request.SentimentValue, request.RequestMessage, request.IsPrivateMessage);
                    _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t Conversation Created");
                    _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t INFERRING INTENT");

                    Message msg = new Message() { text = message };
                    response = await client.PostAsJsonAsync(conversationUrl, msg);



                    if (response.IsSuccessStatusCode)
                    {
                        response = await client.GetAsync(conversationUrl);
                        if (response.IsSuccessStatusCode)
                        {
                            MessageSet BotMessage = response.Content.ReadAsAsync(typeof(MessageSet)).Result as MessageSet;
                            foreach (Message responseMessage in BotMessage.messages)
                            {
                                strReplyMesage = responseMessage.text;
                                Console.WriteLine(strReplyMesage);
                            }
                            responsemessage = strReplyMesage;

                            

                             String str1 = "#username#";

                            if (responsemessage.Contains(str1))
                            {

                                String str2 = " " + request.SenderName + " ";
                                responsemessage = responsemessage.Replace(str1, str2);
                                strReplyMesage = responsemessage;

                            }

                            IsReplyReceived = true;
                        }
                    }
                    _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + "\t replyMessage " + strReplyMesage);
                    // strReplyMesage = "#privatechat#Please send token";
                    char[] delimiterChars = { '#' };
                    string tokenId = "none";
                    string[] words = strReplyMesage.Split(delimiterChars);
                    if (words.Length > 1)
                    {

                        string handshakeKey = words[1];

                        if (handshakeKey.Equals("username"))
                        {
                            strReplyMesage = "Hi " + request.SenderName;
                        }
                        if (handshakeKey.Equals("agent"))
                        {
                            strReplyMesage = words[2];
                        }
                        bool hasTokenCancel = words.Contains("TokenChange");
                        if (hasTokenCancel)
                        {
                            tokenId = generateToken();
                            if (request.IsPrivateMessage == true)
                            {
                                strReplyMesage = "To help you with the requested information, please send the following details - TokenChange : " + " " + conversationRequest.ConversationId + " -" + tokenId + ", <Your First Name>, <Your Policy Number>, <Your address ZipCode>";
                            }
                            else
                            {
                                strReplyMesage = "To help you with the requested information, please send the following details on private chat - TokenChange : " + " " + conversationRequest.ConversationId + " -" + tokenId + ", <Your First Name>, <Your Policy Number>, <Your address ZipCode>";
                            }
                        }
                        else if (handshakeKey.Equals("privatechat"))
                        {
                            tokenId = generateToken();
                            if (request.IsPrivateMessage == true)
                            {
                                strReplyMesage = "To help you with the requested information, please send the following details - Token : " + " " + conversationRequest.ConversationId + " -" + tokenId + ", <Your First Name>, <Your Policy Number>, <Your address ZipCode>";
                            }
                            else
                            {
                                strReplyMesage = "To help you with the requested information, please send the following details on private chat - Token : " + " " + conversationRequest.ConversationId + " -" + tokenId + ", <Your First Name>, <Your Policy Number>, <Your address ZipCode>";
                            }
                        }
                    }

                    if (!String.IsNullOrEmpty(strReplyMesage))
                    {
                        if (strReplyMesage.Contains("#SendToBoth#"))
                        {
                            /*String str = strReplyMesage;
                            str = str.Replace("#SendToBoth#", "*");
                            char[] delimiterChar = { '*' };
                            str = str.Replace("#eoc#", " ");

                            words = str.Split(delimiterChar);
                            String responsetoUser=words[0];
                            String responsetoAgent = words[1];
                            */

                            strReplyMesage = strReplyMesage.Replace("#SendToBoth#", " ");
                            strReplyMesage = strReplyMesage.Replace("#eoc#", " ");
                            flag = true;
                            createConversationResponse(conversationRequest.ConversationRequestId, strReplyMesage, CathyConstants.sendToBoth, null, tokenId, conversationRequest.ConversationId, conversationRequest.PostId, conversationRequest.Sentiment);
                            //createConversationResponse(conversationRequest.ConversationRequestId, responsetoAgent, CathyConstants.sendToAgent, null, tokenId, conversationRequest.ConversationId, conversationRequest.PostId, conversationRequest.Sentiment);
                            //createConversationResponse(conversationRequest.ConversationRequestId, responsetoUser, CathyConstants.sendToUser, null, tokenId, conversationRequest.ConversationId, conversationRequest.PostId, conversationRequest.Sentiment);


                        }
                        else
                        {
                            createConversationResponse(conversationRequest.ConversationRequestId, strReplyMesage, CathyConstants.sendToUser, null, tokenId, conversationRequest.ConversationId, conversationRequest.PostId, conversationRequest.Sentiment);
                        }
                        if (strReplyMesage.Contains("#eoc#"))
                        {
                            strReplyMesage = strReplyMesage.Replace("#eoc#", " ");
                            conversationManager.updateEOCStatusForConversation(conversationRequest.ConversationId, true);

                        }

                    }
                    /*String str1 = "#username#";

                    if (responsemessage.Contains(str1))
                    {
                        
                        String str2 = " " + request.SenderName + " ";
                        responsemessage = responsemessage.Replace(str1, str2);
                        strReplyMesage = responsemessage;

                    }
                    */


                }
                else
                {
                    Console.WriteLine("Error");
                }
                _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t ConReq " + request.PostId + "\tresponse " + strReplyMesage);


            }
        
            //strReplyMesage = LUISreply;
        
            return IsReplyReceived;

            }

        private String ProcessLUISresponse(LUISresponse luisResponse, String LUISreply,CathyRequest request)
        {
            //if (luisResponse.dialog != null)
            {
                if (luisResponse.topScoringIntent.intent == "generalgreetings")
                {
                    LUISreply =  "Hi "+request.SenderName+", how can I help you today ? ";
                    
                }
                else if (luisResponse.topScoringIntent.intent == "None")
                {
                    LUISreply = "Sorry, I'm only trained to help you on workflow items\n";
                }
                else
                {
                    // LUISreply = "GeneralQAUtterence";
                    String USERintent = luisResponse.topScoringIntent.intent;
                    CathyLUISdialog luisdialog = new CathyLUISdialog(request);
                    luisdialog.conversationswitch(USERintent,request);
                    int i = 0;

                    while (!luisdialog.responsereceived)
                    {
                        i++;
                    }


                    Console.Write("No of iterations"+i);
        
                    LUISreply = luisdialog.LUISreply;
                }

                /*
                if (luisResponse.dialog.status == "Finished")
                {
                    //TextBox2.Text = TextBox2.Text +  "\n\nPLM-BOT:: An abort and workflow release intimation has been sent to your TeamCenter manager. You will receive the details via email. Have a nice day! ";
                    query = "";
                    Application["ContextID"] = "";
                    Application["Question"] = "";

                }
                else
                {
                    Application["ContextID"] = luisResponse.dialog.contextId;
                    //Application["Question"] = query;

                }
            }
            else
            {
                TextBox2.Text = TextBox2.Text + "\n\n" + "PLM-BOT:: Sorry, I do not understand you. Please try again";
            }

        */

                return LUISreply;

            }
            return LUISreply;

        }
           static async Task<LUISresponse> askLUIS(HttpResponseMessage response1,Message msg)
        {
            using (var client1 = new HttpClient())
            {
                client1.BaseAddress = new Uri("https://api.projectoxford.ai");
                    
                string id = "8402bacd-07e4-4dd5-af4a-0298e3191aa6";//e32960c9-ebf6-4620-9312-94bc2e7b8aad
                string subscriptionKey = "8954aac0fa6c413fa92437ab8c20c9db";//131c04cfa92d48fcabc529deb75a44f6

                string requestUri = "";

                requestUri = "/luis/v1/application/preview?id=" + id + "&subscription-key=" + subscriptionKey + "&q=" + msg.text;

                HttpResponseMessage response = new HttpResponseMessage();
                 response = await client1.GetAsync(requestUri);

                return JsonConvert.DeserializeObject<LUISresponse>(await response.Content.ReadAsStringAsync());
                //return response;
            }
        }

        /// <summary>
        /// ///////////////////////////////*****************************************//////////////////////////////////////////////////////
        /// </summary>
        /// <returns></returns>

        private async Task<string> GetQAResponse(string query)
        {
            string resultnew = string.Empty;
            string answer = string.Empty;

            using (var client = new HttpClient())
            {
                var scoreRequest = new
                {

                    Inputs = new Dictionary<string, CathyQA>() {
                        {
                            "input1",
                            new CathyQA()
                            {
                                ColumnNames = new string[] {"Query"},
                                Values = new string[,] {  { ""+ query }  }
                            }
                        },
                    },
                    GlobalParameters = new Dictionary<string, string>()
                    {
                    }
                };

                Console.WriteLine("The query is" + scoreRequest);

                const string apiKey = "Vpasiy83I4+gtITmqYA+/EjcD/j5T64xFrF0iD6vx+o6zIFTYNaXxQzfzmx877HUwv4UpCbJ+Jn44ftKHw1jpg=="; // Replace this with the API key for the web service
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/2a883d508ce542d0bf32563cfc5b61a6/services/65e6cdaeded04f2ca6541aec5fa25de8/execute?api-version=2.0&details=true");



                HttpResponseMessage response = await client.PostAsJsonAsync("", scoreRequest);

                if (response.IsSuccessStatusCode)
                {
                    resultnew = await response.Content.ReadAsStringAsync();


                    JObject joResponse = JObject.Parse(resultnew);
                    JObject ojObject = (JObject)joResponse["Results"];
                    JObject jsonoutput = (JObject)ojObject["output1"];
                    JObject jsonvalue = (JObject)jsonoutput["value"];
                    JArray arrvalues = (JArray)jsonvalue["Values"];
                    JArray arrval = (JArray)arrvalues[0];
                    answer = arrval[1].ToString();
                }
                else
                {
                    Console.WriteLine(string.Format("The request failed with status code: {0}", response.StatusCode));

                    // Print the headers - they include the requert ID and the timestamp, which are useful for debugging the failure
                    Console.WriteLine(response.Headers.ToString());

                    string responseContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(responseContent);
                }

                if (answer == "We are a paperless organization. All documents and billing will be through email only.")
                {
                    answer = "You know, we are going green. All policy documents will be emailed to you";
                }

                return answer;


            }
        }

        //////////////////////////////////////////*****************************************////////////////////////////
        private static string generateToken()
        {
            string tokenId;
            var rnd = new Random(DateTime.Now.Millisecond);
            int ticks = rnd.Next(0, 3000);
            tokenId = ticks.ToString();
            return tokenId;
        }

        private static HttpClient setupHttpClient()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(Service_URL);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("BotConnector", secret_key);
            return client;
        }

        private async Task<bool> PostMessageForSwitch(string message,String conversationId, UserProfile userprofile, CathyRequest request)
        {
            bool IsReplyReceived = false;
            ConversationManager conversationManager = new ConversationManager();

            //  Conversation conversationObj = null;
            HttpClient client = setupHttpClient();
            HttpResponseMessage response = await client.GetAsync("/api/tokens/").ConfigureAwait(false);

            if (response.IsSuccessStatusCode)
            {
                var conversation = new CathyConversation();
                response = await client.PostAsJsonAsync("/api/conversations/" + conversationId + "/messages", conversation);
                if (response.IsSuccessStatusCode)
                {
                    CathyConversation ConversationInfo = new CathyConversation();
                    string conversationUrl = null;

                    response = await client.PostAsJsonAsync("/api/conversations", conversation);
                    ConversationInfo = response.Content.ReadAsAsync(typeof(CathyConversation)).Result as CathyConversation;
                    conversationId =ConversationInfo.conversationID ;
                    conversationUrl = conversationId + "/messages/";
                    Conversation conversationObj = conversationManager.createConversation(userprofile, conversationId, request.Channel, request.PostId, request.ParentPostId, request.IsPrivateMessage, request.SentimentValue, request.RequestMessage, true);
                    userprofileManager.updateConversationDetailsForSender(conversationId, request.Channel, request.IsPrivateMessage, request.SenderId, true);
                    userprofile.LastCathyConversationId = conversationId;
                    ConversationRequest conversationRequest = conversationManager.createConversationRequest(conversationId, request.PostId, request.SentimentValue, request.RequestMessage, request.IsPrivateMessage);

                    Message msg = new Message() { text = message };
                    response = await client.PostAsJsonAsync(conversationUrl, msg);
                    if (response.IsSuccessStatusCode)
                    {
                        response = await client.GetAsync(conversationUrl);
                        if (response.IsSuccessStatusCode)
                        {
                            MessageSet BotMessage = response.Content.ReadAsAsync(typeof(MessageSet)).Result as MessageSet;
                            foreach (Message responseMessage in BotMessage.messages)
                            {
                                //MessageBox.Show(responseMessage.text);
                                strReplyMesage = responseMessage.text;
                                Console.WriteLine(strReplyMesage);
                            }
                            Console.WriteLine(strReplyMesage);
                            IsReplyReceived = true;
                        }
                    }
                    createConversationResponse(conversationRequest.ConversationRequestId, strReplyMesage, CathyConstants.sendToUser, null, CathyConstants.noToken, conversationRequest.ConversationId, conversationRequest.PostId, conversationRequest.Sentiment);
                    
                }
                else
                {
                    Console.WriteLine("Error");
                }



            }
            return IsReplyReceived;

        }
        public CathyResponse processAgentMessageForUser(CathyRequest request)
        {
            CathyResponse response = new CathyResponse();
             
            char[] delimiterChars = { ']' };

            string[] words = request.RequestMessage.Split(delimiterChars);
            string conversationId = words[0].Remove(0,1);
            string message = words[1];

            UserProfile userprofile =  userprofileManager.getUserProfileForAgentConversation(conversationId);
           
            Conversation conversation = conversationManager.getUserAgentConversation(conversationId);
            if (conversation == null)
            {
                conversation = conversationManager.getCathyConversation(conversationId);
            }
            ConversationRequest conversationRequest = conversationManager.getConversationRequest(conversationId);
            if (userprofile != null && conversation != null)
            {

                if (!String.IsNullOrEmpty(userprofile.TwitterId))
                {
                    response.SenderId = userprofile.TwitterId;

                }
                else if (!String.IsNullOrEmpty(userprofile.FbDirectId))
                {
                    response.SenderId = userprofile.FbDirectId;


                }
                else if (!String.IsNullOrEmpty(userprofile.FbWallId))
                {
                    response.SenderId = userprofile.FbWallId;


                }
                response.Channel = conversation.Channel;
                response.IsPrivateMessage = conversationRequest.IsPrivateMessage;
                response.PostId = conversationRequest.PostId;
                response.Action = CathyConstants.sendToUser;
                response.ResponseMessage = message;
                response.AgentId = conversation.ConversationAgentId;

                
                createConversationResponse(conversationRequest.ConversationRequestId, message, response.Action, response.AgentId, CathyConstants.noToken,conversationRequest.ConversationId , conversationRequest.PostId, conversationRequest.Sentiment);
                
            }
            else
            {
                response.Channel = request.Channel;
                response.SenderId = request.SenderId;
                response.IsPrivateMessage = request.IsPrivateMessage;
                response.PostId = request.PostId;
                response.Action = CathyConstants.sendToAgent;
                response.ResponseMessage = "Incorrect Conversation Id given";
                response.AgentId = "";
                createConversationResponse(conversationRequest.ConversationRequestId, message, response.Action, response.AgentId, CathyConstants.noToken, conversationRequest.ConversationId, request.PostId, conversationRequest.Sentiment);
                
            }
            

            return response;

        }

        public CathyResponse processInvalidTokenMessageForUser(CathyRequest request, UserProfile userprofile, String errorMessage)
        {
            string conversationId = null;
            CathyResponse response = new CathyResponse();
            response.Channel = request.Channel;
            response.IsPrivateMessage = request.IsPrivateMessage;
            response.PostId = request.PostId;
            response.Action = CathyConstants.sendToUser;
            response.ResponseMessage = errorMessage;
            response.AgentId = "";
            if (!String.IsNullOrEmpty(userprofile.LastUserAgentConversationId))
            {
                conversationId = userprofile.LastUserAgentConversationId;
            }
            else
            {
                conversationId = userprofile.LastCathyConversationId;
            }
            if (String.IsNullOrEmpty(conversationId))
            {
                conversationId = Guid.NewGuid().ToString();
                Conversation conversation =conversationManager.createConversation(conversationId, request.Channel, request.SenderId, request.ParentPostId, request.PostId, false);
            }
            ConversationRequest conversationRequest = conversationManager.createConversationRequest(conversationId, request.PostId, request.SentimentValue, request.RequestMessage, request.IsPrivateMessage);

            createConversationResponse(conversationRequest.ConversationRequestId, response.ResponseMessage, response.Action, response.AgentId, CathyConstants.noToken, conversationRequest.ConversationId, conversationRequest.PostId, conversationRequest.Sentiment);
            

            return response;

        }

        private CathyResponse processNegativeMessageForAgent(CathyRequest request, UserProfile userprofile)
        {
            CathyResponse response = new CathyResponse();
            // create Conversation and conversation request
            String conversationId = null;
            Conversation conversation = null;
            if (String.IsNullOrEmpty(userprofile.LastUserAgentConversationId))
            {
                conversationId = Guid.NewGuid().ToString();
                conversation = conversationManager.createConversation(conversationId, request.Channel, request.SenderId, request.ParentPostId, request.PostId, false);
                userprofileManager.updateConversationDetailsForSender(conversationId, request.Channel, request.IsPrivateMessage, request.SenderId, false);
            }
            else
            {
                conversationId = userprofile.LastUserAgentConversationId;
            }
           
            ConversationRequest conversationRequest = conversationManager.createConversationRequest(conversationId, request.PostId, request.SentimentValue, request.RequestMessage, request.IsPrivateMessage);

            // send the conversation message to human agent
            //create CathyResponse and send to Agent
            string customerInfo = getCustomerInfo(request);
            response = new CathyResponse();
            response.Channel = request.Channel;
            response.IsPrivateMessage = request.IsPrivateMessage;
            response.PostId = request.PostId;
            response.ResponseMessage ="["+ conversationId+"]["+request.SenderId+ "]][" + request.SenderName + "]" + customerInfo+"[NegativePost]" + request.RequestMessage;
            response.SenderId = request.SenderId;
            response.Action = CathyConstants.sendToAgent;
            response.AgentId = userprofileManager.findAgentConversationID(request.Channel);
            createConversationResponse(conversationRequest.ConversationRequestId, response.ResponseMessage, response.Action, response.AgentId, CathyConstants.noToken, conversationRequest.ConversationId, conversationRequest.PostId, conversationRequest.Sentiment);
            return response;

        }

        public CathyResponse processMessageForNonRepliedPost(UserProfile userprofile, CathyRequest request)
        {
            CathyResponse response = new CathyResponse();
            // create Conversation and conversation request
           
            Conversation conversation = null;
            ConversationRequest conversationRequest = null;
            //if (String.IsNullOrEmpty(userprofile.LastUserAgentConversationId))
            //{
            //    String conversationId = Guid.NewGuid().ToString();
            //    conversation = conversationManager.createConversation(conversationId, request.Channel, request.SenderId, request.ParentPostId, request.PostId, false);
            //    userprofileManager.updateConversationDetailsForSender(conversationId, request.Channel, request.IsPrivateMessage, request.SenderId, false);
            //    conversationRequest = conversationManager.createConversationRequest(conversationId, request.PostId, request.SentimentValue, request.RequestMessage, request.IsPrivateMessage);
            //}
            //else
            {
                conversation = conversationManager.getCathyConversation(userprofile.LastCathyConversationId);
                conversationRequest = conversationManager.getConversationRequest(conversation.ConversationId);
            }
            // send the conversation message to human agent
            //create CathyResponse and send to Agent
            string customerInfo = getCustomerInfo(request);
            response = new CathyResponse();
            response.Channel = request.Channel;
            response.IsPrivateMessage = request.IsPrivateMessage;
            response.PostId = request.PostId;
            response.ResponseMessage = "["+conversation.ConversationId +"]["+request.SenderId+ "]["+request.SenderName+ "]"+customerInfo+"[NonRepliedPost]" + request.RequestMessage;
            response.SenderId = request.SenderId;
            response.Action = CathyConstants.sendToAgent;
            response.AgentId = userprofileManager.findAgentConversationID(request.Channel);
            createConversationResponse(conversationRequest.ConversationRequestId, response.ResponseMessage, response.Action, response.AgentId, CathyConstants.noToken, conversationRequest.ConversationId, conversationRequest.PostId, request.SentimentValue);
            return response;

        }

        private string getCustomerInfo(CathyRequest request)
        {
            Customer customer = new Customer();
            string customerId = customer.getCustomerId(request.SenderId, request.Channel, request.IsPrivateMessage);
            string customerInfo = "";
            if (!String.IsNullOrEmpty(customerId))
            {
                customerInfo = "[" + customerId + "]";
            }
            return customerInfo;
        }

        private UserProfile getUserProfile(CathyRequest request)
        {
            UserProfile userprofile = userprofileManager.getUserProfile(request.SenderId, request.Channel, request.IsPrivateMessage);
            if (userprofile == null)
            {
                userprofile = userprofileManager.createUserProfile(request.SenderId, request.SenderName, request.Channel, request.IsPrivateMessage);

            }
            return userprofile;
        }

    private CathyResponse processTokenMessage(CathyRequest request, UserProfile userprofile)
    {
        CathyResponse response = null;
        //Token:XXXX, <Your FirstName>, <Your Policy number> , <Your address ZipCode>   
        // string errorMessage = "";
        char[] delimiterChars = { ':' };
        char[] delimiterCharsComma = { ',' };
        string[] tokenIdStr = request.RequestMessage.Split(delimiterChars);
            if (tokenIdStr.Length < 2)
            {
                response = processInvalidTokenMessageForUser(request, userprofile, "Invalid message format. Please provide message as Token : <tokenid>");
            }
            else
            {
                string token = tokenIdStr[1];
                string[] tokenArray = token.Split(delimiterCharsComma);
                char[] delimiterChars1 = { '-' };
                string[] str = tokenArray[0].Split(delimiterChars1);
                string strConversationId = str[0].Trim();
                string strTokenId = str[1].Trim();

                ConversationRequest conversationWallRequest = conversationManager.getConversationRequest(strConversationId);
                if (conversationWallRequest != null)
                {
                    string storedToken = conversationManager.getConversationResponseToken(conversationWallRequest.ConversationRequestId);
                    if ((!String.IsNullOrEmpty(storedToken)) && storedToken.Equals(strTokenId))
                    {
                        Console.WriteLine("private chat can started");
                        _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + " \t BOT request = " + request.RequestMessage);
                        var taskMsg = PostMessageForSwitch(request.RequestMessage, strConversationId, userprofile, request).GetAwaiter().GetResult();
                        _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t PostId " + request.PostId + " \t BOT Response = " + strReplyMesage);
                        Console.WriteLine(strReplyMesage);
                        response = new CathyResponse();
                        response.SenderId = request.SenderId;
                        response.Channel = request.Channel;
                        response.IsPrivateMessage = request.IsPrivateMessage;
                        response.PostId = request.PostId;
                        
                        response.ResponseMessage = strReplyMesage;
                        if (flag)
                        {
                            response.Action = CathyConstants.sendToBoth;
                            response.AgentId = userprofileManager.findAgentID(request.Channel);
                            flag = false;
                        }
                        else
                        {
                            response.Action = CathyConstants.sendToUser;
                            response.AgentId = null;
                        }
                        response.Action = CathyConstants.sendToUser;
                        
                        return response;

                    }
                    else
                    {
                        Console.WriteLine("private chat cannot be started token is incorrect or not present");
                        response = processInvalidTokenMessageForUser(request, userprofile, "Invalid token, please provide correct token");
                    }
                }
                else
                {
                    Console.WriteLine("private chat cannot be started- conversation is not present");
                    response = processInvalidTokenMessageForUser(request, userprofile, "Invalid token, please provide correct token");
                    
                }
            }
            return response;

        }

        private void createConversationResponse(string conversationRequestId, string strReplyMesage, string replyAction, string agentId, string tokenId, string conversationId, string postId, string sentiment)
        {
            ConversationResponse response = conversationManager.createConversationResponse(conversationRequestId, strReplyMesage, replyAction, agentId, tokenId);
            conversationManager.createConversationResponseFeedback(conversationId, response.ConversationResponseId, postId);
            conversationManager.createConversationSentimentFeedback(conversationId, conversationRequestId, response.ConversationResponseId, sentiment);
           // conversationManager.updateSentimentForConversation(conversationId, sentiment);
        }

        private void loadClientDetails()
        {
        }

        private class CathyQA
        {
           public string[] ColumnNames { get; set; }
           public string[,]  Values { get; set; }

        }
    }
   

}