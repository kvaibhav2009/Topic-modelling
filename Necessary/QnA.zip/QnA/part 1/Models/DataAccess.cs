﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql;
using System.Data;

namespace CathyRestAPI.Models
{
    public class DataAccess
    {

        public DataTable ExecuteParamerizedSelectCommand(string CommandName,
                 CommandType cmdType, NpgsqlParameter[] param)
        {
            NpgsqlConnection con = null;
            con = new NpgsqlConnection(CathyConstants.connectionString);

            NpgsqlCommand cmd = null;
            DataTable table = new DataTable();

            cmd = con.CreateCommand();

            cmd.CommandType = cmdType;
            cmd.CommandText = CommandName;
            cmd.Parameters.AddRange(param);

            try
            {
                con.Open();
                NpgsqlDataAdapter da = null;
                using (da = new NpgsqlDataAdapter(cmd))
                {
                    da.Fill(table);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                cmd = null;
                con.Close();
            }
            Console.WriteLine("the dataable in dataacess " + table);
            return table;
        }

        public DataTable ExecuteSelectCommand(string CommandName,
                CommandType cmdType)
        {
            NpgsqlConnection con = null;
            con = new NpgsqlConnection(CathyConstants.connectionString);

            NpgsqlCommand cmd = null;
            DataTable table = new DataTable();

            cmd = con.CreateCommand();

            cmd.CommandType = cmdType;
            cmd.CommandText = CommandName;
         

            try
            {
                con.Open();
                NpgsqlDataAdapter da = null;
                using (da = new NpgsqlDataAdapter(cmd))
                {
                    da.Fill(table);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                cmd = null;
                con.Close();
            }
            Console.WriteLine("the dataable in dataacess " + table);
            return table;
        }

        public bool ExecuteNonQuery(string CommandName, CommandType cmdType, NpgsqlParameter[] pars)
        {
            NpgsqlConnection con = null;
            con = new NpgsqlConnection(CathyConstants.connectionString);

            NpgsqlCommand cmd = null;
            int res = 0;

            cmd = con.CreateCommand();

            cmd.CommandType = cmdType;
            cmd.CommandText = CommandName;
            cmd.Parameters.AddRange(pars);

            try
            {
                con.Open();

                res = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                cmd = null;
                con.Close();
            }

            if (res >= 1)
            {
                return true;
            }
            return false;
        }

        
    }
}