﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace CathyRestAPI.Models
{
    public class CathyNewModel
    {
        CathyRequest request;

        public String response = string.Empty;

        public string getpolicy = string.Empty;

        public string customername = string.Empty;

        public bool pass = false;

        public LUISnegativeSentiment luis = null;

        public String intent = string.Empty;

        public CathyNewModel(CathyRequest request)
        {
            this.request = request;              
        }

        public async void ConversationFlow()
        {
            //Message msg = (Message)request.RequestMessage;
            Task.Run(async () =>
            {
                luis = await GetIntent(request.RequestMessage);
                intent = luis.topScoringIntent.intent;
            }).Wait();
            

            switch (intent)
            {
                case "None" :
                      response = "Please retry";
                      break;
                case "Frustration":
                      frustration();
                      break;
                case "Notworking":
                      response =" Understand your frustration "+request.SenderName+", but would request you to share your zip code, so that I can help you";
                      break;
                case "Zipcodeprovided":
                      Zipcodeprovided();
                      break;
                case "Phonenumberprovided":
                      Phonenumberprovided();
                      break;
                case "NameDOBprovided":
                      NameDOBprovided();
                      break;
                case "Affirmative":
                      Affirmative();
                      break;  
                case "Declined":response = "Welcome, have a great day!";
                      bool t = NegativeSentimentDBManager.setSentimentForUser(request.SenderId, false);
                      bool v = CathyBuffer.clearsenderId(request.SenderId);
                      break;
                                            
            }

            pass = true;

        }

        public void Affirmative()
        {

            String getval = CathyBuffer.validateRetrieveUserDetails(request.SenderId, "email");
            getpolicy = CathyBuffer.validateRetrieveUserDetails(request.SenderId, "policyno");
            customername = CathyBuffer.validateRetrieveCustomername(request.SenderId, "customer_name");
            // response = "Sure " + request.SenderName + " we’re sending the documents rightaway to "+getval+" .Do come back and let me know if you don’t get the email within 6 hours. Anything else I can help you with? ";
            response = "Affirmative";

        }

        public void NameDOBprovided()
        {
             String fname = string.Empty;
            String dob = string.Empty;

            bool success = false;
            foreach (Entities1 entityreceived in luis.entities)
            {
                if (entityreceived.type == "name")
                {
                    fname = entityreceived.entity;
                }
                if (entityreceived.type == "dob")
                {
                    dob = entityreceived.entity;
                    
                }
            }

            dob = ConverttoMMDDYYYY(dob);

            success = CathyBuffer.UpdateNameDOB(request.SenderId,fname,dob);

            if(success)
            {
                String getval = CathyBuffer.validateRetrieveUserDetails(request.SenderId,"policyno");
                if (getval == "No values")
                    response = "Invalid details provided.Please retry";
                else
                    response = "Got it, I see that you have taken the auto policy " + getval + " about a month back.I am going to issue a notification to resend the policy document immediately to your primary home address. Give it about 2 - 3 business days. Do you need a copy immediately on email?";

            }
            else
            {
                response = "Invalid details provided.Please retry";
            }

        }

        public string ConverttoMMDDYYYY(string dob)
        {
            char[] delimiterChars = { '/' };
          
            string[] words = dob.Split(delimiterChars);
            if (words.Length == 3)
            {
            dob=words[2]+"/"+words[0]+"/"+words[1];
            }
            dob = dob.Replace("/", "-");
            dob = dob.Replace(" ", "");
            return dob;
        }


        public class BufferValues
        {
            public string fname = string.Empty;
            public string dob = string.Empty;
            public string phoneno = string.Empty;
            public string policy = string.Empty;
            public string emailid = string.Empty;
        }

        public void Phonenumberprovided()
        {
            response = "Excellent! We’re almost there. What have you mentioned as name and date of birth for the policy holder?";
            String phonenumber = string.Empty;
            String nospacesphonenumber = string.Empty;
            bool success = false;
            foreach (Entities1 entityreceived in luis.entities)
            {
                if (entityreceived.type == "phonenumber")
                {
                    phonenumber = entityreceived.entity;
                    break;
                }
            }
            nospacesphonenumber = phonenumber.Trim();
            nospacesphonenumber = phonenumber.Replace(" ","");
            phonenumber = nospacesphonenumber;
            success = CathyBuffer.Updatephonenumber(request.SenderId, phonenumber);
        }
    
        public void frustration()
        {
            if (!request.IsPrivateMessage)
            {
                //response = "Hi " + request.SenderName + ", apologies for the delay. I would like to help you in sorting this out. Can we go on to private chat so that I can validate a few personal details to trace your policy";
				response = "Apologies for the delay. I would like to help you in sorting this out quickly. Can you please message me on private chat?";

            }
            else
            {
                response = "Hi " + request.SenderName + ", apologies for the inconvenience";
            }              

        }
        public void Zipcodeprovided()
        {
            response = "Thanks, I just need to validate few more details so that I can get the right policy. What’s the contact number you mentioned on your policy ?";
            String zipcode = string.Empty;
            bool success = false;
            foreach(Entities1 entityreceived in luis.entities)
            {
                if (entityreceived.type == "zipcode")
                {
                    zipcode = entityreceived.entity;
                    break;
                }
            }
            success=CathyBuffer.InsertZipcode(request.SenderId,zipcode);

        }
        

        static async Task<LUISnegativeSentiment> GetIntent(String msg)
        {
            using (var client1 = new HttpClient())
            {
                client1.BaseAddress = new Uri("https://api.projectoxford.ai");

                //string id = "";//e32960c9-ebf6-4620-9312-94bc2e7b8aad
                string subscriptionKey = "8954aac0fa6c413fa92437ab8c20c9db";//131c04cfa92d48fcabc529deb75a44f6

                string requestUri = "";

                requestUri = "luis/v2.0/apps/8e5bba46-5cf8-40d2-afcf-e34e1e6db1e5?subscription-key=" + subscriptionKey + "&q=" + msg;

                HttpResponseMessage response = new HttpResponseMessage();
                response = await client1.GetAsync(requestUri);


                return JsonConvert.DeserializeObject<LUISnegativeSentiment>(await response.Content.ReadAsStringAsync());
                //return response;


            }

        }

    }
} 