﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class ConversationRequest
    {

       public string ConversationRequestId { get; set; }
        public string ConversationId { get; set; }
        public String PostId { get; set; }
        public String RequestMessage { get; set; }
        public String Sentiment { get; set; }
        public Boolean IsPrivateMessage { get; set; }
        public DateTime CreatedDate { get; set; }


        public ConversationRequest(string conversationRequestId, string conversationId, string postId, string requestMessage, string sentiment, bool isPrivateMessage, DateTime createdDate)
        {
            this.ConversationRequestId = conversationRequestId;
            this.ConversationId = conversationId;
            this.PostId = postId;
            this.RequestMessage = requestMessage;
            this.Sentiment = sentiment;
            this.IsPrivateMessage = isPrivateMessage;
            this.CreatedDate = createdDate;
        }

    }
}