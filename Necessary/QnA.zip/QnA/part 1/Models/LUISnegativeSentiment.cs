﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    

        public class LUISnegativeSentiment
        {
            public string query { get; set; }
            public TopScoringIntent1 topScoringIntent { get; set; }
            public Entities1[] entities { get; set; }

        }
        
        public class Entities1
        {
            public string entity { get; set; }
            public string type { get; set; }
            public string startIndex { get; set; }
            public string endIndex { get; set; }
            public string score { get; set; }
           
        }

        public class TopScoringIntent1
        {
            public string intent { get; set; }
            public string score { get; set; }
            
        }




    
}