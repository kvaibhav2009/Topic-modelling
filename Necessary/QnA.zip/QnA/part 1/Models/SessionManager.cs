﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

namespace CathyRestAPI.Models
{
    public class SessionManager
    {
        public static string conversationStage = "0";
        public static HttpSessionState Session = System.Web.HttpContext.Current.Session; // { get; }

        public static HttpContext context = HttpContext.Current;

        public static void setSession(String param,String value)
        {
            //System.Web.HttpContext.Current.Session[param] = value;
            //if (Session[param].Equals(null))
            //Session.Add("conversationStage", conversationStage);
            //Session[param] = value;
            //return;
           // context.Session();

            var session = HttpContext.Current.Session;

            if (Session != null)
            {
                Session.ToString();

                Session["conversationStage"] = Session["conversationStage"] as string;
                Session[param] = value;

                Session["conversationStage"] = Session["conversationStage"] as string;


                //Session = HttpContext.Current.Session;
                //s.Session[param] = value.ToString();
                Session[param] = HttpContext.Current.User.Identity.Name.ToString();
                Session[param] = value.ToString();
            }
            else
            {
                conversationStage = "1";
            }

        }

        public static string getSession(String param)
        {

            String sessionvalue = (String)Session[param];

            return sessionvalue;

        }

    }
}