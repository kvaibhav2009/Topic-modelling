﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CathyRestAPI.Models
{
    public class ConversationResponseFeedback
    {

        string FeedbackId { get; set; }
        string ConversationId { get; set; }
        string ConversationResponseId { get; set; }
        string PostId { get; set; }
        string Feedback { get; set; }
        string FeedbackComments { get; set; }
        string FeedbackGivenBy { get; set; }
        DateTime CreatedDate { get; set; }

        

        public ConversationResponseFeedback(string feedbackId, string conversationId, string conversationResponseId, string postId, DateTime createdDate)
        {
            this.FeedbackId = feedbackId;
            this.ConversationId = conversationId;
            this.ConversationResponseId = ConversationResponseId;
            this.PostId = postId;
            this.CreatedDate = createdDate;

        }
    }
}