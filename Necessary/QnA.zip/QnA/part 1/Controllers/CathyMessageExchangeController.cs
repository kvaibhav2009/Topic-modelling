﻿using CathyRestAPI.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Tracing;
using System.Web.SessionState;

namespace CathyRestAPI.Controllers
{
 [EnableCors(origins: "http://170.248.47.136", headers: "*", methods: "*",SupportsCredentials = true)]
    public class CathyMessageExchangeController : ApiController
    {
        private static TraceSource _source = new TraceSource("Logs");

        
        public static HttpSessionState Session = System.Web.HttpContext.Current.Session; // { get; }

        public static System.Web.HttpContext context = HttpContext.Current;
        
        public string GetCathyMessageExchange()
        {
            return "HelloWorld ";
        }
		public void OptionsCathyMessageExchange()
        {
            _source.TraceEvent(TraceEventType.Information, 0, "Options " );
           
        }
        public CathyResponse PostCathyMessageExchange(CathyRequest request)
        {
            //System.Web.HttpContext.Current.SetSessionStateBehavior(System.Web.SessionState.SessionStateBehavior.Required);

            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t message exchange start");
            CathyRequestOrchestrator objRequestOrchestrator = new CathyRequestOrchestrator();
            CathyResponse response = objRequestOrchestrator.processMessage(request);
            _source.TraceEvent(TraceEventType.Information, 0, DateTime.Now.ToString("h:mm:ss tt") + "\t message exchange end");
            return response;
        }
    }
}
