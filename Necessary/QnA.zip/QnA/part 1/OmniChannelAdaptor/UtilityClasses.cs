﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UtilityClasses
{
    class ReturnOnInvestment
    {
        public static string maturityDateFinder(int investmentPeriod)
        {
            DateTime currentDate = DateTime.Now;
            DateTime maturityDate = currentDate.AddMonths(investmentPeriod);
            return maturityDate.ToString();
        }

        public static string maturityAmount(double investmentAmount, int investmentPeriod)
        {
            double investmentInYears = investmentPeriod / 12;
            double maturityAmount = (investmentAmount * investmentPeriod) * (1 + (0.1 * investmentInYears));
            return maturityAmount.ToString();
        }
    }
}

