﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using static CathyOmniChannelRestClient.CathyBanking;
using System.ComponentModel;


namespace CathyOmniChannelRestClient
{
    class CathyOmniChannelAdaptor
    {
        static String serviceResponse = null;
        static String serviceResponseError = "The service trying to be accessed is down/Unavailable at the moment";
        static cathyResponse cathyError;

        // Method for validating New Investment
        public static cathyResponse validateNewInvestment(NewInvestment jsonInvestment)
        {

            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            String url = "http://170.248.47.136/services/rest/save/validateNewInvestment";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            var javaScriptSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = 9999999;
            string JsonObjectInvestment = javaScriptSerializer.Serialize(jsonInvestment);

            if (request != null)
            {
                request.Method = "POST";
                request.ReadWriteTimeout = 100000000;
                Byte[] byteArray = encoding.GetBytes(JsonObjectInvestment);
                request.ContentLength = byteArray.Length;
                request.ContentType = @"application/json";
                using (Stream dataStream = request.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                }
                long length = 0;
                try
                {
                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    {
                        if (response == null)
                            throw new NullReferenceException("Response recieved was null \n");
                        length = response.ContentLength;
                        using (Stream s = response.GetResponseStream())
                        {
                            using (TextReader textReader = new StreamReader(s, true))
                            {
                                serviceResponse = textReader.ReadToEnd();
                                #region Deserialization
                                #endregion
                            }
                        }
                    }

                }

                catch (WebException ex)
                {
                    // Console.WriteLine(ex.Message); Log Exception Message here
                }
            }
            else
            {
                cathyError = javaScriptSerializer.Deserialize<cathyResponse>(serviceResponseError);
                return cathyError;

            }
            cathyResponse cathyValidateInvestmentResponse = javaScriptSerializer.Deserialize<cathyResponse>(serviceResponse);
            return cathyValidateInvestmentResponse;
        }

        //Method for creating a new Investment
        public static cathyResponse createNewInvestment(NewInvestment jsonInvestment)
        {

            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            String url = "http://170.248.47.136/services/rest/save/saveNewInvestment";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            var javaScriptSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = 9999999;
            string JsonObjectInvestment = javaScriptSerializer.Serialize(jsonInvestment);

            if (request != null)
            {
                request.Method = "POST";
                request.ReadWriteTimeout = 100000000;
                Byte[] byteArray = encoding.GetBytes(JsonObjectInvestment);
                request.ContentLength = byteArray.Length;
                request.ContentType = @"application/json";
                using (Stream dataStream = request.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                }
                long length = 0;
                try
                {
                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    {
                        if (response == null)
                            throw new NullReferenceException("Response recieved was null \n");
                        length = response.ContentLength;
                        using (Stream s = response.GetResponseStream())
                        {
                            using (TextReader textReader = new StreamReader(s, true))
                            {
                                serviceResponse = textReader.ReadToEnd();
                                #region Deserialization
                                #endregion
                            }
                        }
                    }

                }

                catch (WebException ex)
                {
                    // Console.WriteLine(ex.Message); Log Exception Message here
                }
            }
            else
            {
                cathyError = javaScriptSerializer.Deserialize<cathyResponse>(serviceResponseError);
                return cathyError;
            }

            cathyResponse cathyCreateInvestmentResponse = javaScriptSerializer.Deserialize<cathyResponse>(serviceResponse);
            return cathyCreateInvestmentResponse;
        }

        // Method for authenticating OTP
        public static cathyResponse authenticateOTP(AuthenticateOTP jsonContentOTP)
        {

            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            String url = "http://170.248.47.136/services/rest/get/authenticateOtp";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            var javaScriptSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = 9999999;
            string JsonObjectOTP = javaScriptSerializer.Serialize(jsonContentOTP);

            if (request != null)
            {
                request.Method = "POST";
                request.ReadWriteTimeout = 100000000;
                Byte[] byteArray = encoding.GetBytes(JsonObjectOTP);
                request.ContentLength = byteArray.Length;
                request.ContentType = @"application/json";
                using (Stream dataStream = request.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                }
                long length = 0;
                try
                {
                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    {
                        if (response == null)
                            throw new NullReferenceException("Response recieved was null \n");
                        length = response.ContentLength;
                        using (Stream s = response.GetResponseStream())
                        {
                            using (TextReader textReader = new StreamReader(s, true))
                            {
                                serviceResponse = textReader.ReadToEnd();
                                #region Deserialization
                                #endregion
                            }
                        }
                    }

                }

                catch (WebException ex)
                {
                    // Console.WriteLine(ex.Message); Log Exception Message here
                }
            }
            else
            {
                cathyError = javaScriptSerializer.Deserialize<cathyResponse>(serviceResponseError);
                return cathyError;
            }

            cathyResponse cathyAuthenticateOTPResponse = javaScriptSerializer.Deserialize<cathyResponse>(serviceResponse);
            return cathyAuthenticateOTPResponse;
        }


        // Method for Getting OTP 
        public static getResponse getOTP(gettingOTP jsonContentGetOTP)
        {

            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            String url = "http://170.248.47.136/services/rest/get/getOtp";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            var javaScriptSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = 9999999;
            string JsonObjectGetOTP = javaScriptSerializer.Serialize(jsonContentGetOTP);

            if (request != null)
            {
                request.Method = "POST";
                request.ReadWriteTimeout = 100000000;
                Byte[] byteArray = encoding.GetBytes(JsonObjectGetOTP);
                request.ContentLength = byteArray.Length;
                request.ContentType = @"application/json";
                using (Stream dataStream = request.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                }
                long length = 0;
                try
                {
                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    {
                        if (response == null)
                            throw new NullReferenceException("Response recieved was null \n");
                        length = response.ContentLength;
                        using (Stream s = response.GetResponseStream())
                        {
                            using (TextReader textReader = new StreamReader(s, true))
                            {
                                serviceResponse = textReader.ReadToEnd();
                                #region Deserialization
                                #endregion
                            }
                        }
                    }

                }

                catch (WebException ex)
                {
                    // Console.WriteLine(ex.Message); Log Exception Message here
                }
            }
            else
            {
                getResponse cathyError = javaScriptSerializer.Deserialize<getResponse>(serviceResponseError);
                return cathyError;
            }

            getResponse cathyGetOTPResponse = javaScriptSerializer.Deserialize<getResponse>(serviceResponse);
            return cathyGetOTPResponse;
        }

        // Method for getting user profile
        public static RootObject getUserProfile(GetUserProfile jsonContentUserProfile)
        {

            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            String url = "http://170.248.47.136/services/rest/get/getUserProfile";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            var javaScriptSerializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = 9999999;
            string JsonObjectUserProfile = javaScriptSerializer.Serialize(jsonContentUserProfile);

            if (request != null)
            {
                request.Method = "POST";
                request.ReadWriteTimeout = 100000000;
                Byte[] byteArray = encoding.GetBytes(JsonObjectUserProfile);
                request.ContentLength = byteArray.Length;
                request.ContentType = @"application/json";
                using (Stream dataStream = request.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                }
                long length = 0;
                try
                {
                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    {
                        if (response == null)
                            throw new NullReferenceException("Response recieved was null \n");
                        length = response.ContentLength;
                        using (Stream s = response.GetResponseStream())
                        {
                            using (TextReader textReader = new StreamReader(s, true))
                            {
                                serviceResponse = textReader.ReadToEnd();
                                #region Deserialization
                                #endregion
                            }
                        }
                    }

                }

                catch (WebException ex)
                {
                    // Console.WriteLine(ex.Message); Log Exception Message here
                }
            }
            else
            {
                RootObject cathyError = javaScriptSerializer.Deserialize<RootObject>(serviceResponseError);
                return cathyError;
            }

            // Remove this part of code if you want to return Account Number in string format
            RootObject cathyGetUserProfileResponse = javaScriptSerializer.Deserialize<RootObject>(serviceResponse);
            return cathyGetUserProfileResponse;

        }


    }
}
