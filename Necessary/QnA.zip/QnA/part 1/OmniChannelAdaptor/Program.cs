﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CathyOmniChannelRestClient
{
    class CathyBanking
    {
        public class Investment
        {
            public string accountNumber { get; set; }
            public string accountType { get; set; }
            public string investmentAmount { get; set; }
            public string maturityDate { get; set; }
            public string maturityAmount { get; set; }
            public int interestRate { get; set; }
            public string actionOnMaturity { get; set; }
            public string investmentBeneficiary { get; set; }
            public string liquidateInAccount { get; set; }
        }

        public class NewInvestment
        {
            public Investment investment { get; set; }
        }

        public class AuthenticateOTP
        {
            public string otp { get; set; }
            public string jSessionId { get; set; }
            public customerGeneric customer { get; set; }
        }

        public class customerGeneric
        {
            public string customerId { get; set; }
        }

        public class gettingOTP
        {
            public string jSessionId { get; set; }
            public customerGeneric customer { get; set; }
        }

        public class GetUserProfile
        {
            public string accountType { get; set; }
            public customerGeneric customer { get; set; }
        }


        public class cathyResponse
        {
            public string exitCode { get; set; }
        }


        //Response class used for getUserProfile

        public class AccountList
        {
            public int accountNr { get; set; }
            public string accountType { get; set; }
            public int balance { get; set; }
            public int netExpense { get; set; }
            public int netIncome { get; set; }
            public string accountNumber { get; set; }
            public string relManager { get; set; }
            public string iban { get; set; }
            public string availableBalance { get; set; }
            public string accountBalance { get; set; }
            public string preferredAccount { get; set; }
            public string currency { get; set; }
            public string type { get; set; }
        }

        public class Customer
        {
            public int ID { get; set; }
            public string name { get; set; }
            public List<AccountList> accountList { get; set; }
            public string mobileNumber { get; set; }
        }

        public class RootObject
        {
            public string errorCode { get; set; }
            public object callMode { get; set; }
            public object cardDetails { get; set; }
            public object transfers { get; set; }
            public object investmentList { get; set; }
            public Customer customer { get; set; }
            public object messages { get; set; }
            public object beneficiaries { get; set; }
            public object otp { get; set; }
            public object transfer { get; set; }
            public string response { get; set; }
            public object message { get; set; }
        }

        public class getResponse
        {
            public string errorCode { get; set; }
            public object callMode { get; set; }
            public object messages { get; set; }
            public object beneficiaries { get; set; }
            public object customer { get; set; }
            public object investmentList { get; set; }
            public object otp { get; set; }
            public object transfers { get; set; }
            public object cardDetails { get; set; }
            public object transfer { get; set; }
            public string response { get; set; }
            public string message { get; set; }
        }

        static void Main(string[] args)
        {
            Investment invester = new Investment
            {
                accountNumber = "067610108308",
                accountType = "Recurring Deposit",
                investmentAmount = "2000",
                maturityDate = "2018-9-1",
                maturityAmount = "2200",
                interestRate = 10,
                actionOnMaturity = "Reinvest Principal Amount",
                investmentBeneficiary = "John Keyees",
                liquidateInAccount = "067610108308"
            };

            NewInvestment newInvest = new NewInvestment
            {
                investment = invester
            };

            customerGeneric cust = new customerGeneric
            {
                customerId = "john"
            };

            AuthenticateOTP validOTP = new AuthenticateOTP
            {
                otp = "263740",
                jSessionId = "abcd",
                customer = cust
            };

            GetUserProfile userProfile = new GetUserProfile
            {
                accountType = "SALARIED",
                customer = cust
            };

            gettingOTP otpRequest = new gettingOTP
            {
                jSessionId = "abcd",
                customer = cust
            };


            // CREATING A mockup response of customer List
            AccountList DummyListAccountList = new AccountList
            {
                accountNr = 0,
                accountType = "CURRENT",
                balance = 0,
                netExpense = 0,
                netIncome = 0,
                accountNumber = "067610108308",
                relManager = "Mario Ross",
                iban = "INIL02453656564789",
                availableBalance = "504560",
                accountBalance = "10000000",
                preferredAccount = "Y",
                currency = "INR",
                type = "SAVINGS",
            };


            cathyResponse OTPResponse = CathyOmniChannelAdaptor.authenticateOTP(validOTP);
            Console.WriteLine("Authenticate OTP Resposne :\n");
            Console.Out.WriteLine("ExitCode :" + OTPResponse.exitCode);
            Console.Out.WriteLine("\n");

            getResponse OTPnew = CathyOmniChannelAdaptor.getOTP(otpRequest);
            Console.Out.WriteLine("OTP Response:" + OTPnew.otp);
            Console.Out.WriteLine("\n");

            RootObject CustomerDetailsResponse = CathyOmniChannelAdaptor.getUserProfile(userProfile);
            //Code to return account Number as string
            string customerAccountNumber = null;
            string customerBalance = null;
            List<AccountList> AccNumberList = CustomerDetailsResponse.customer.accountList;
            List<string> accountNumber = AccNumberList.Select(o => o.accountNumber).ToList();
            foreach (String acnNumber in accountNumber)
            {
                // return acnNumber;
                customerAccountNumber = acnNumber;
            }

            List<string> accountBalance = AccNumberList.Select(o => o.accountBalance).ToList();
            foreach (String acnBalance in accountBalance)
            {
                // return acnNumber;
                customerBalance = acnBalance;
            }

            Console.Out.WriteLine("Account Number:" + customerAccountNumber);
            Console.Out.WriteLine("Account Balance :" + customerBalance);
        }
    }
}
